/************************MONITOR HOARE BUFFER SINGOLO*********************************/

//-----------------------PROCEDURE.H-----------------------------

#ifndef HEADER_H
#define HEADER_H

#include "monitor_hoare.h"


struct ProdCons {
	int buffer;
	int buffer_libero; // 1 se libero, 0 se pieno
	int buffer_occupato; // 0 se libero, 1 se pieno
	Monitor m;
};

//definisco le varcond
#define VARCOND_PRODUTTORI 0
#define VARCOND_CONSUMATORI 1

void Produci(struct ProdCons * pc, int valore);
int Consuma(struct ProdCons * pc);

#endif



/*--------------------------PROCEDURE.C------------------------ */
#include "procedure.h"

#include <stdio.h>

void Produci(struct ProdCons * pc, int valore) {

	//entro nel monitor
	enter_monitor( &(pc->m) );
	printf("Ingresso monitor - produzione\n");

	//se il buffer è occupato, metto in attesa i produttori
	if( pc->buffer_occupato == 1 ) {
		printf("Sospensione - produzione\n");
		wait_condition( &(pc->m), VARCOND_PRODUTTORI );
		printf("Riattivazione - produzione\n");
	}

	//Aggiorno il valore e lo stato del buffer
	pc->buffer = valore;
	pc->buffer_libero = 0;
	pc->buffer_occupato = 1;

	printf("Produzione (%d)\n", valore);

	//segnalo ai consumatori che ho finito di produrre
	signal_condition( &(pc->m), VARCOND_CONSUMATORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - produzione\n");
}

int Consuma(struct ProdCons * pc) {

	int valore;

	//entro nel monitor
	enter_monitor( &(pc->m) );
	printf("Ingresso monitor - consumazione\n");

	//controllo che il buffer è libero, se lo è metto in attesa i consumatori
	if( pc->buffer_libero == 1 ) {
		printf("Sospensione - consumazione\n");
		wait_condition( &(pc->m), VARCOND_CONSUMATORI );
		printf("Riattivazione - consumazione\n");
	}

	//aggiornamento valori e stato del buffer
	valore = pc->buffer;
	pc->buffer_libero = 1;
	pc->buffer_occupato = 0;

	printf("Consumazione (%d)\n", valore);

	//segnalo ai produttori che ho smesso di consumare
	signal_condition( &(pc->m), VARCOND_PRODUTTORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - consumazione\n");

	return valore;
}


/*-------------------------MONITOR HOARE.H-----------------------*/
//fornito dalla traccia
typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//id del semaforo per realizzare la coda urgent
  int urgent_sem;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition e della coda urgent
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

//contatore del numero di processi sospesi sulla coda urgent
  int *urgent_count;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 


/*--------------------------MONITOR HOARE.C-----------------*/
//fornito dalla traccia
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>
#include "monitor_hoare.h"


//Funzioni di utilita' private alla libreria Monitor

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo

void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza il semaforo per la coda urgent
    M->urgent_sem=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->urgent_sem,0,SETVAL,0);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition, più un contatore per la coda urgent
    M->id_shared=shmget(IPC_PRIVATE,(num_var+1)*sizeof(int),IPC_CREAT|0664);

    printf("(num_var+1)*sizeof(int) = %d\n", (num_var+1)*sizeof(int));

    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));
    
    printf("M->cond_counts %p\n", M->cond_counts);

    M->num_var_cond = num_var;
    
    M->urgent_count = M->cond_counts + M->num_var_cond;

    printf("M->urgent_count %p\n", M->urgent_count);

    //inizializza i contatori per le var.condition e per la coda urgent
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;

    *(M->urgent_count)=0;

    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);

} 

void enter_monitor(Monitor * M){


    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );

    Wait_Sem(M->mutex,0);
    printf("<%d> Entrato nel monitor \n",getpid() );

}

void leave_monitor(Monitor* M){

    printf("<%d> Uscito dal monitor  \n", getpid());

    if( *(M->urgent_count) > 0 ) {
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
        Signal_Sem(M->urgent_sem,0); 
    } else {
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
        Signal_Sem(M->mutex,0);
    }
}

void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->urgent_sem,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n", getpid());


}

void wait_condition(Monitor* M,int id_var){


    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }



    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);


      M->cond_counts[id_var]=M->cond_counts[id_var]+1;

      if( *(M->urgent_count) > 0 ) {

	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());

          Signal_Sem(M->urgent_sem,0); 
      } else {

	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());

          Signal_Sem(M->mutex,0);
      }

      Wait_Sem(M->id_conds,id_var);

      M->cond_counts[id_var]=M->cond_counts[id_var]-1;
}

void signal_condition(Monitor* M,int id_var){

    if(id_var<0 || id_var>=M->num_var_cond) {
       printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }


   printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
     

    (*(M->urgent_count))++;

    if(M->cond_counts[id_var]>0) {

            Signal_Sem(M->id_conds,id_var);


            printf("<%d> -Monitor- invocata la signal sulla condition numero %d\n", getpid(), id_var);



            printf("<%d> -Monitor- processo in attesa sulla coda urgent \n", getpid());
            Wait_Sem(M->urgent_sem,0);
            printf("<%d> -Monitor- processo uscito dalla coda urgent \n", getpid());


    }

    (*(M->urgent_count))--;
}

int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}

void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}


/*------------------MAIN.C--------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "procedure.h"

//traccia
#define NUM_PRODUTTORI 1
#define NUM_CONSUMATORI 1


int main() {

	key_t chiave_shm = IPC_PRIVATE; //se ho + eseguibili ftok(".", 'a');
	int id_shm = shmget( chiave_shm, sizeof(struct ProdCons), IPC_CREAT|0664);
	if( id_shm < 0 ) {
		perror("errore shm");
		exit(1);
	}

	//attach
	struct ProdCons * pc = shmat( id_shm, NULL, 0);
	if( pc == (void*)-1 ) {
		perror("errore shmat");
		exit(1);
	}

    //inizializzo il monitor
	init_monitor( &(pc->m), 2 );

	//inizializzo lo stato del buffer
	pc->buffer_libero = 1;
	pc->buffer_occupato = 0;

	int j;
	pid_t pid;

	for(j=0; j<NUM_CONSUMATORI; j++) {

		pid = fork();
		if( pid == 0 ) {
			// figlio consumatore
			printf("Inizio consumatore\n");

			int valore = Consuma( pc );
			printf("Consumazione: %d\n", valore);

			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}


	for(j=0; j<NUM_PRODUTTORI; j++) {

		pid = fork();
		if( pid == 0 ) {
			// figlio produttore
			printf("Inizio produttore\n");

			sleep(5);
			srand(time(NULL)); //inizializzo il generatori di numeri casuali, altrimenti ogni programma genera la stessa seq. di numeri
			int valore = rand() % 10;

			Produci( pc, valore);
			printf("Produzione: %d\n", valore);
			
			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}


	//attendo la fine dei produttori e consumatori
	for(j=0; j<NUM_CONSUMATORI+NUM_PRODUTTORI; j++) {
		wait(NULL);
	}

    //rimozione monitor e shm
	remove_monitor( &(pc->m) );
	shmctl( id_shm, IPC_RMID, 0);

	return 0;
}