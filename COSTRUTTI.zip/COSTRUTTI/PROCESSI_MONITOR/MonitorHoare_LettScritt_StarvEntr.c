/***************************LETTURA E SCRITTURA STAVATION ENTRAMBI HOARE*********************/

/*--------------------PROCEDURE.H------------------------------*/
#ifndef HEADER_H
#define HEADER_H

#include "monitor_hoare.h"

struct LettScritt {
	int buffer;
	int numero_lettori;
	int numero_scrittori;
	Monitor m;
};

//VARCOND per starvation
#define VARCOND_LETTORI 0
#define VARCOND_SCRITTORI 1

void Scrivi(struct LettScritt * ls, int valore);
int Leggi(struct LettScritt * ls);

#endif


/*---------------------PROCEDURE.C-----------------------------*/
#include "procedure.h"

#include <unistd.h>
#include <stdio.h>


int Leggi(struct LettScritt * ls) {

	int valore;

	//entro nel monitor
	enter_monitor( &(ls->m) );
	printf("Lettura - ingresso monitor\n");

	//posso leggere solo quando non ci sono scrittori, posso anche avere più lettori
	if( ls->numero_scrittori > 0 ) {
		printf("Sospensione - lettura\n");
        // Nel caso signal_and_wait, lo scrittore segnala e va in attesa, e quindi può segnalare
        // solo un lettore invece di tutti come per la soluzione signal_and_continue.
		wait_condition( &(ls->m), VARCOND_LETTORI );
		printf("Riattivazione - lettura\n");
	}

	//incremento il numero di lettori
	ls->numero_lettori++;
	printf("Numero lettori ++ : %d\n", ls->numero_lettori);

	/*
	 * NOTA: Ogni lettore riattiva il lettore successivo
	 * (il primo lettore attiva il secondo ancora in attesa;
	 * il secondo lettore attiva il terzo; etc.)
	 */
	signal_condition( &(ls->m), VARCOND_LETTORI );

	//esco dal monitor
	leave_monitor( &(ls->m) );

	// ...operazione lenta...
	sleep(2);

	//aggiorno il valore 
	valore = ls->buffer;
	printf("Lettura - valore [%d]\n", valore);

    //da qui in poi inizia la funz FineLettura
	//entro nel monitor
	enter_monitor( &(ls->m) );

	//decremento il numero di lettori
	ls->numero_lettori--;
	printf("Numero lettori -- : %d\n", ls->numero_lettori);

	/*
	 * NOTA: l'ultimo lettore ad abbandonare la risorsa
	 * riattiva uno degli scrittori in attesa
	 */
	if( ls->numero_lettori == 0 ) {
		printf("Lettura - signal su scrittori\n");
		signal_condition( &(ls->m), VARCOND_SCRITTORI );
	}

	//esco dal monitor
	leave_monitor( &(ls->m) );
	printf("Lettura - uscita monitor\n");

	return valore; //perchè non è void
}


void Scrivi(struct LettScritt * ls, int valore) {

	//entro nel monitor
	enter_monitor( &(ls->m) );
	printf("Scrittura - ingresso monitor\n");

	//per scrivere, non ci devono essere nè altri scrittori, nè altri lettori
	if(ls->numero_lettori > 0 || ls->numero_scrittori > 0) {
		printf("Scrittura - sospensione\n");
		wait_condition( &(ls->m), VARCOND_SCRITTORI ); //metto in attesa gli scrittori
		printf("Scrittura - riattivazione\n");
	}

	//incremento gli scrittori
	ls->numero_scrittori++;
	printf("Numero scrittori ++ : %d\n", ls->numero_scrittori);

	//esco dal monitor
	leave_monitor( &(ls->m) );


	// ...operazione lenta...
	sleep(1);

	//prelevo il valore dal buffer
	ls->buffer = valore;
	printf("Scrittura - valore [%d]\n", valore);


    //da qui inizia la funz FineScrittura
	//entro nel monitor
	enter_monitor( &(ls->m) );

	//decremento gli scrittori
	ls->numero_scrittori--;
	printf("Numero scrittori -- : %d\n", ls->numero_scrittori);


	/*
	 * NOTA: per bilanciare la starvation, si verifica se ci
	 * sono scrittori in attesa, e se ne riattiva uno se presente.
	 * Altrimenti, si riattiva un lettore.
	 */
	//contorllo sulla coda scrittori (usa la varcond SCRITTORI) per vedere se ce n'è sono
	if( queue_condition( &(ls->m), VARCOND_SCRITTORI ) ) {
		printf("Scrittura - signal su scrittori\n");
		signal_condition( &(ls->m), VARCOND_SCRITTORI );

	} else {
		/*
		 * NOTA: si effettua una singola signal_cond e si riattiva
		 * un solo un processo lettore. Per questo motivo,
		 * il primo lettore a svegliarsi dovrà fare anche lui una
		 * signal_cond per riattivare il secondo lettore in attesa;
		 * il secondo lettore dovrà riattivare il terzo lettore; etc.
		 */
		printf("Scrittura - signal su lettori\n");

		signal_condition( &(ls->m), VARCOND_LETTORI ); //signal normale perchè monitor hoare o sigwait
	}

	//esco dal monitor
	leave_monitor( &(ls->m) );
	printf("Scrittura - uscita monitor\n");
}



/*---------------------MONITOR HOARE.H-------------------------------*/

/***PROTOTIPI DELLE PROCEDURE PER LA REALIZZAZIONE DEL COSTRUTTO MONITOR***/


typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//id del semaforo per realizzare la coda urgent
  int urgent_sem;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition e della coda urgent
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

//contatore del numero di processi sospesi sulla coda urgent
  int *urgent_count;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 


/*----------------------MONITO HOARE.C---------------------*/

// Implementazione di un Monitor 


#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>
#include "monitor_hoare.h"


//Funzioni di utilita' private alla libreria Monitor

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo


void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza il semaforo per la coda urgent
    M->urgent_sem=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->urgent_sem,0,SETVAL,0);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition, più un contatore per la coda urgent
    M->id_shared=shmget(IPC_PRIVATE,(num_var+1)*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;

    M->urgent_count = M->cond_counts + M->num_var_cond;


    //inizializza i contatori per le var.condition e per la coda urgent
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;

    *(M->urgent_count)=0;

#ifdef DEBUG_
    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);
#endif

} 



void enter_monitor(Monitor * M){

#ifdef DEBUG_
    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );
#endif

    Wait_Sem(M->mutex,0);

#ifdef DEBUG_
    printf("<%d> Entrato nel monitor \n",getpid() );
#endif

}


void leave_monitor(Monitor* M){

#ifdef DEBUG_
    printf("<%d> Uscito dal monitor  \n", getpid());
#endif

    if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
        Signal_Sem(M->urgent_sem,0); 
    } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
        Signal_Sem(M->mutex,0);
    }
}


void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->urgent_sem,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

#ifdef DEBUG_
    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n", getpid());
#endif

}

void wait_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);
#endif

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;

      if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
          Signal_Sem(M->urgent_sem,0); 
      } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
          Signal_Sem(M->mutex,0);
      }

      Wait_Sem(M->id_conds,id_var);

      M->cond_counts[id_var]=M->cond_counts[id_var]-1;
}

void signal_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
#endif     

    (*(M->urgent_count))++;

    if(M->cond_counts[id_var]>0) {

            Signal_Sem(M->id_conds,id_var);

#ifdef DEBUG_
            printf("<%d> -Monitor- invocata la signal sulla condition numero %d\n", getpid(), id_var);
#endif

#ifdef DEBUG_
            printf("<%d> -Monitor- processo in attesa sulla coda urgent \n", getpid());
#endif

            Wait_Sem(M->urgent_sem,0);

#ifdef DEBUG_
            printf("<%d> -Monitor- processo uscito dalla coda urgent \n", getpid());
#endif

    }

    (*(M->urgent_count))--;
}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}



void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}


/*------------------------MAIN.C-------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "procedure.h"

#define NUM_LETTORI 3
#define NUM_SCRITTORI 3

#define LETTURE 3
#define SCRITTURE 2

int main() {

	key_t chiave_shm = IPC_PRIVATE; //ftok(".", 'a'); se ho + eseguibili
	int id_shm = shmget(chiave_shm, sizeof(struct LettScritt), IPC_CREAT|0664);
	if( id_shm < 0 ) {
		perror("errore shm");
		exit(1);
	}

    //attach
	struct LettScritt * ls = shmat( id_shm, NULL, 0);
	if(ls == (void*)-1) //perchè il puntatore non deve puntare a zero
	{
		perror("errore shmat");
		exit(1);
	}

    //inizializzo monitor e variabili
	init_monitor( &(ls->m), 2); //2 perchè ho 2 varcond

	//inizializzo la struttura
	ls->numero_lettori = 0; 
	ls->numero_scrittori = 0;

	pid_t pid;
	int j;
	for(j=0; j<NUM_LETTORI; j++) {
		pid = fork();
		if( pid == 0 ) {
			// figlio lettore
			printf("Inizio lettore\n");

			int k;
			for(k=0; k<LETTURE; k++) //la traccia dice che devo fare tot letture
			{

				int valore = Leggi( ls );
				sleep(1);
			}
			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}



	for(j=0; j<2; j++) {
		pid = fork();
		if( pid == 0 ) {
			// figlio scrittore
			printf("Inizio scrittore\n");

			srand(time(NULL)*getpid()); //inizializzo il gen di numeri casuali

			sleep(1);

			int k;
			for(k=0; k<SCRITTURE; k++) //traccia dice che devo fare tot scritture
			 {
				int valore = rand() % 10;
				Scrivi(ls, valore);

				sleep(2);
			}
			exit(0);
		}
	}

    //volendo posso fare anche due for separati per lettori e scrittori j<NUM_LETTORI e j<NUM_SCRITTORI
	for(j=0; j<NUM_LETTORI+NUM_SCRITTORI; j++)
		wait(NULL);

    //rimozione monitor e shm
	remove_monitor( &(ls->m) );
	shmctl( id_shm, IPC_RMID, 0);

	return 0;
}