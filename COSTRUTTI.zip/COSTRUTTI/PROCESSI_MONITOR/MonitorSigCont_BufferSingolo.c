/***********************MONITOR SIGCONT BUFFER SINGOLO******************************** */

/*--------------------------PROCEDURE.H-----------------------*/
#ifndef HEADER_H
#define HEADER_H  

#include "monitor_signal_continue.h"
   
struct ProdCons {
	int buffer;
	int buffer_libero; // 1 se libero, 0 se pieno
	int buffer_occupato; // 0 se libero, 1 se pieno
	Monitor m;
};

//definisco le varcond
#define VARCOND_PRODUTTORI 0
#define VARCOND_CONSUMATORI 1

void Produci(struct ProdCons * pc, int valore);
int Consuma(struct ProdCons * pc);

#endif


/*--------------------------PROCEDURE.c-----------------------*/
#include "procedure.h"

#include <stdio.h>

void Produci(struct ProdCons * pc, int valore) {
	
	//devo sempre prima entrare nel monitor
	enter_monitor( &(pc->m) ); 
	printf("Ingresso monitor - produzione\n");

	//finchè il buffer è pieno, metto in attesa i produttori
	while( pc->buffer_occupato == 1 ) {
		printf("Sospensione - produzione\n");
		wait_condition( &(pc->m), VARCOND_PRODUTTORI );
		printf("Riattivazione - produzione\n");
	}

	//assegno il valore al buffer e imposto lo stato
	pc->buffer = valore;
	pc->buffer_libero = 0;
	pc->buffer_occupato = 1;
	printf("Produzione (%d)\n", valore);

	//segnalo ai consumatori che la produzione è finita
	signal_condition( &(pc->m), VARCOND_CONSUMATORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - produzione\n");
}

int Consuma(struct ProdCons * pc) {

	int valore;

	//entro nel monitor 
	enter_monitor( &(pc->m) ); //sempre prima di ogni operazione devo entrare nel moitor
	printf("Ingresso monitor - consumazione\n");

	//finchè il buffer è libero, non posso consumare e quindi sospendo i consumatori
	while( pc->buffer_libero == 1 ) {
		printf("Sospensione - consumazione\n");
		wait_condition( &(pc->m), VARCOND_CONSUMATORI );
		printf("Riattivazione - consumazione\n");
	}

	//altrimenti prelevo il valore del buffer e aggiorno lo stato
	valore = pc->buffer;
	pc->buffer_libero = 1;
	pc->buffer_occupato = 0;
	printf("Consumazione (%d)\n", valore);

	//segnalo la fine della consumazione ai produttori
	signal_condition( &(pc->m), VARCOND_PRODUTTORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - consumazione\n");

	return valore;
}


/*--------------------------MONITOR SIGCONT.H-----------------------*/
#ifndef __MONITOR_H
#define __MONITOR_H

typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 


#endif


/*--------------------------MONITOR SIGCONT.C-----------------------*/
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>
#include "monitor_signal_continue.h"

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo


void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition
    M->id_shared=shmget(IPC_PRIVATE,num_var*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;



    //inizializza i contatori per le var.condition
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;

    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);

} 



void enter_monitor(Monitor * M){

    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );

    Wait_Sem(M->mutex,0);

    printf("<%d> Entrato nel monitor \n",getpid() );

}


void leave_monitor(Monitor* M){


    printf("<%d> Uscito dal monitor  \n", getpid());
    printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());


    Signal_Sem(M->mutex,0);
}


void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n", getpid());

}

void wait_condition(Monitor* M,int id_var){

    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;


	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());

      Signal_Sem(M->mutex,0);
     

	printf("<%d> -Monitor- wait sul semaforo %d del monitor \n", getpid(),id_var);

      Wait_Sem(M->id_conds,id_var);

	printf("<%d> -Monitor- wait sul mutex del monitor \n", getpid());
   
	Wait_Sem(M->mutex,0);
}

void signal_condition(Monitor* M,int id_var){

    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }

    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
     


   if(M->cond_counts[id_var] > 0){
	M->cond_counts[id_var]--;
	
    	printf("<%d> -Monitor- signal sul semaforo %d\n", getpid(), id_var);
	
	Signal_Sem(M->id_conds,id_var);
   }

}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}



void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}


/*------------------------------main.c------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "procedure.h"

//traccia
#define NUM_PRODUTTORI 1 //posso anche non definirli quando è 1 solo
#define NUM_CONSUMATORI 1


int main() {

    //creazione e controlo shm
	key_t chiave_shm = IPC_PRIVATE; //ftok(".", 'a'); se ho + eseguibili
	int id_shm = shmget( chiave_shm, sizeof(struct ProdCons), IPC_CREAT|0664);
	if( id_shm < 0 ) {
		perror("errore shm");
		exit(1);
	}

    //attach
	struct ProdCons * pc = shmat( id_shm, NULL, 0);
	if( pc == (void*)-1 ) {
		perror("errore shmat");
		exit(1);
	}

    //inizializzo il monitor
	init_monitor( &(pc->m), 2 ); //2 perchè ho 2 varcond

	//inizializzo il buffer
	pc->buffer_libero = 1;
	pc->buffer_occupato = 0;

	int j;
	pid_t pid;
	for(j=0; j<NUM_CONSUMATORI; j++) {

		pid = fork();
		if( pid == 0 ) {
			// figlio consumatore
			printf("Inizio consumatore\n");

			int valore = Consuma( pc );
			printf("Consumazione: %d\n", valore);

			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}


	for(j=0; j<NUM_PRODUTTORI; j++) {
		pid = fork();
		if( pid == 0 ) {
			// figlio produttore
			printf("Inizio produttore\n");
			sleep(5);

			srand(time(NULL)); //inizializzo il gen di numeri casuali altrimenti tutti i programmi avranno la stessa seq di numeri
			int valore = rand() % 10;
			Produci( pc, valore);
			printf("Produzione: %d\n", valore);
			
			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}

	//terminazioni processi, posso anche fare due for separati
	for(j=0; j<NUM_CONSUMATORI+NUM_PRODUTTORI; j++) {
		wait(NULL);
	}

    //rimozione monitor e shm
	remove_monitor( &(pc->m) );
	shmctl( id_shm, IPC_RMID, 0);

	return 0;
}