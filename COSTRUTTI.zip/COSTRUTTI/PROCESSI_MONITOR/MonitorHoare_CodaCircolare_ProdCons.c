/****************************PRODCONS CODA CIRCOLARE MONITOR DI HOARE*********************/

//-------------------------monitor_hoare.h------------------------------------
typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//id del semaforo per realizzare la coda urgent
  int urgent_sem;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition e della coda urgent
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

//contatore del numero di processi sospesi sulla coda urgent
  int *urgent_count;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 



//----------------------------------monitor_hoare.c-----------------------------------
// Implementazione di un Monitor signal-and-wait, con coda urgent (soluzione di Hoare)
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>

#include "monitor_hoare.h"


//Funzioni di utilita' private alla libreria Monitor

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo

void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza il semaforo per la coda urgent
    M->urgent_sem=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->urgent_sem,0,SETVAL,0);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition, più un contatore per la coda urgent
    M->id_shared=shmget(IPC_PRIVATE,(num_var+1)*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;

    M->urgent_count = M->cond_counts + M->num_var_cond;


    //inizializza i contatori per le var.condition e per la coda urgent
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;

    *(M->urgent_count)=0;

#ifdef DEBUG_
    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);
#endif

} 



void enter_monitor(Monitor * M){

#ifdef DEBUG_
    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );
#endif

    Wait_Sem(M->mutex,0);

#ifdef DEBUG_
    printf("<%d> Entrato nel monitor \n",getpid() );
#endif

}


void leave_monitor(Monitor* M){

#ifdef DEBUG_
    printf("<%d> Uscito dal monitor  \n", getpid());
#endif

    if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
        Signal_Sem(M->urgent_sem,0); 
    } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
        Signal_Sem(M->mutex,0);
    }
}


void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->urgent_sem,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

#ifdef DEBUG_
    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n");
#endif

}

void wait_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);
#endif

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;

      if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
          Signal_Sem(M->urgent_sem,0); 
      } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
          Signal_Sem(M->mutex,0);
      }

      Wait_Sem(M->id_conds,id_var);

      M->cond_counts[id_var]=M->cond_counts[id_var]-1;
}

void signal_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
#endif     

    (*(M->urgent_count))++;

    if(M->cond_counts[id_var]>0) {

            Signal_Sem(M->id_conds,id_var);

#ifdef DEBUG_
            printf("<%d> -Monitor- invocata la signal sulla condition numero %d\n", getpid(), id_var);
#endif

#ifdef DEBUG_
            printf("<%d> -Monitor- processo in attesa sulla coda urgent \n", getpid());
#endif

            Wait_Sem(M->urgent_sem,0);

#ifdef DEBUG_
            printf("<%d> -Monitor- processo uscito dalla coda urgent \n", getpid());
#endif

    }

    (*(M->urgent_count))--;
}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}


void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}


//-------------------------------ProdCons.h----------------------------------------
#ifndef _PRODCONS_
#define _PRODCONS_

#include "monitor_hoare.h"

#define DIM N

//stati del buffer
#define LIBER0 0
#define OCCUPATO1 1
#define INUSO 2

//definiamo le varcond
#define VAR_PROD 0
#define VAR_CONS 1

typedef struct {

    int buffer[DIM];

    /* TBD: Introdurre ulteriori variabili per la gestione del vettore 
    e per la sincronizzazione */
            int testa;
            int coda;
            int count;
            Monitor M;
} MonitorVettoreCircolare;

void init_monitor_circolare(MonitorVettoreCircolare * p);
void produzione_circolare(MonitorVettoreCircolare * p, int val);
int consumazione_circolare(MonitorVettoreCircolare * p);
void remove_monitor_circolare(MonitorVettoreCircolare * p);

#endif




//--------------------------ProdCons.c----------------------------------
#include <stdio.h>

#include "prodcons.h"

void init_monitor_circolare(MonitorVettoreCircolare * p) {

    /* TBD: Inizializzare il monitor e variabili */
    init_monitor(&(p->M),2); //2 sono le varcond

    //possiamo inizializzare queste var anche nel main
    p->testa=0;
    p->coda=0;
    p->count=0;
}

void produzione_circolare(MonitorVettoreCircolare * p, int val) {
    /* TBD: Completare la produzione nel buffer circolare con sincronizzazione */
    enter_monitor(&(p->M));

    //se la coda è piena, metto in attesa i produttori
    if(p->count==DIM){
        wait_condition(&(p->M),VAR_PROD);
    }
    
    //imposto il valore secondo la prod circolare
    p->buffer[p->testa] = val;
  
    //update puntatore di coda
    p->testa = (p->testa+1) % DIM;
    p->count++;
    
    //segnalo ai consumatori che ho finito di produrre
    signal_condition( &(p->M), VAR_CONS );

    leave_monitor( &(p->M));
}

int consumazione_circolare(MonitorVettoreCircolare * p) {
    /* TBD: Completare la consumazione dal buffer circolare con sincronizzazione */
    enter_monitor(&(p->M));

    //controllo che il buffer sia vuoto
    if(p->count==0){
     wait_condition(&(p->M),VAR_CONS);   
    }

    int val;

    //consumo il valore secondo la consumazione circolare
    val = p->buffer[p->coda];

    //update puntatore di testa
    p->coda = (p->coda + 1) % DIM;
    p->count--;
    
    //segnalo i produttori che la consumazione è terminata
    signal_condition( &(p->M), VAR_PROD );

    leave_monitor( &(p->M) );

    return val;
}

void remove_monitor_circolare(MonitorVettoreCircolare * p) {

    /* TBD: Disattivare l'oggetto monitor */
    remove_monitor(&(p->M));
}



//----------------------------------------main.c------------------------------------ù
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "prodcons.h"

void Produttore(MonitorVettoreCircolare *p);
void Consumatore(MonitorVettoreCircolare *p);

int main() {

    //dato che per fare la shmat ho bisogno dell'id della chiave, me la vado a creare per entrambi i monitor

    key_t key_shm1 = ftok(".",'a'); //oppure IPC_PRIVATE
	int ds_shm1 = shmget(key_shm1,sizeof(MonitorVettoreCircolare),IPC_CREAT|0664);

    //attach
    MonitorVettoreCircolare * p = ( MonitorVettoreCircolare*) shmat(ds_shm1,NULL,0);/* TBD: Allocare l'oggetto MonitorVettoreCircolare in memoria condivisa */

    //INIZIALIZZO IL monitor richiamandomi il valore del monitor
    init_monitor_circolare(p);


    /* TBD: Creare un processo figlio, che esegua la funzione "Produttore()" */
    pid_t pid;
    pid= fork();
    if(pid==0){
    Produttore(p,b); //richiamo la funzione e gli passo valore monitor e buffer
    exit(0);
    }


    /* TBD: Creare un processo figlio, che esegua la funzione "Consumatore()" */
    pid=fork();
    if(pid==0){
    Consumatore(p,b); //richiamo la funzione e gli passo valore monitor e buffer
    exit(0);
    }


    /* TBD: Attenere la terminazione dei processi figli */
    for(int i=0;i<2;i++)
    wait(NULL);

    //rimuovo il monitor
    remove_monitor_circolare(p);

    /* TBD: Deallocare gli oggetti monitor */
    shmctl(ds_shm1,IPC_RMID,0);
}


void Produttore(MonitorVettoreCircolare *p) {

    int numero_elementi = rand() % 10; //TRACCIA

    printf("[PRODUTTORE] Totale elementi da produrre: %d\n", numero_elementi);

    //produzione di elemento randomico tra 0 e 10 e inserimento in vettore circolare
    for(int i=0; i<numero_elementi; i++) {
    
        sleep(1);

        int val = rand() % 10;

        printf("[PRODUTTORE] Prodotto: %d\n", val);

        /* TBD: Chiamare la funzione "produzione_circolare" per produrre
                il valore "val"
         */
        produzione_circolare(p,val);
    }
}

void Consumatore(MonitorVettoreCircolare *p) {

	int numero_elementi = 10; //il numero inserito è a caso perchè la traccia era diversa
 	
    for(int i=0; i<numero_elementi; i++) {

        /* TBD: Chiamare la funzione "consumazione_circolare" per prelevare
    		un valore e copiarlo in "val"
         */

        int val = consumazione_circolare(p); /* TBD */

        printf("[CONSUMATORE] Consumato: %d\n", val);
    }
}
