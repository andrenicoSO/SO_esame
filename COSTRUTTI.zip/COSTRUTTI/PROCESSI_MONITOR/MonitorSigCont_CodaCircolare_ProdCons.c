/***************************PRODCONS CODA CIRCOLARE MONITOR SIGNAL CONTINUE   (da modificare?)****************/
//--------------------------------monitor_signal_continue.h----------------------------
#ifndef __MONITOR_H
#define __MONITOR_H

typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 


#endif



//------------------------------monitor_signal_continue.c-------------------------------
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>

#include "monitor_signal_continue.h"

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo


void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition
    M->id_shared=shmget(IPC_PRIVATE,num_var*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;



    //inizializza i contatori per le var.condition
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;


#ifdef DEBUG_
    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);
#endif

} 



void enter_monitor(Monitor * M){

#ifdef DEBUG_
    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );
#endif

    Wait_Sem(M->mutex,0);

#ifdef DEBUG_
    printf("<%d> Entrato nel monitor \n",getpid() );
#endif

}


void leave_monitor(Monitor* M){

#ifdef DEBUG_
    printf("<%d> Uscito dal monitor  \n", getpid());
    printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif 

    Signal_Sem(M->mutex,0);
}


void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

#ifdef DEBUG_
    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n");
#endif

}

void wait_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);
#endif

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;


#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif

      Signal_Sem(M->mutex,0);
     
#ifdef DEBUG_
	printf("<%d> -Monitor- wait sul semaforo %d del monitor \n", getpid(),id_var);
#endif

      Wait_Sem(M->id_conds,id_var);

#ifdef DEBUG_
	printf("<%d> -Monitor- wait sul mutex del monitor \n", getpid());
#endif
   
	Wait_Sem(M->mutex,0);
}

void signal_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
#endif     


   if(M->cond_counts[id_var] > 0){
	M->cond_counts[id_var]--;
	#ifdef DEBUG_
    	printf("<%d> -Monitor- signal sul semaforo %d\n", getpid(), id_var);
	#endif
	Signal_Sem(M->id_conds,id_var);
   }

}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}


void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}




//-----------------------------------procedure.h----------------------------------
#ifndef __PROCEDURE_H
#define __PROCEDURE_H

#include "monitor_signal_continue.h"

#define DIM 3 //3 lo dà traccia

typedef struct{
	int buffer[DIM];
	
	/* TBD: Completare la definizione di questa struttura,
	 * aggiungendo un sotto-oggetto Monitor, le variabili testa e coda,
	 * ed eventualmente (a scelta dello studente) una variabile "contatore"
	 */
	 int count;
	 int testa;
	 int coda;
	 Monitor M;
}PriorityProdCons;


void inizializza_prod_cons(PriorityProdCons* p);
void produci_alta_prio(PriorityProdCons* p );
void produci_bassa_prio(PriorityProdCons* p);
void consuma(PriorityProdCons* p);
void rimuovi_prod_cons(PriorityProdCons* p);

#endif



//--------------------------------procedure.c------------------------------------
#include "procedure.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

/* TBD: Definire delle macro per identificare le variabili condition */
//le priorità le chiede la traccia, altrimenti un solo prod e un solo cons+
#define CV_ALTA_P 0
#define CV_BASSA_P 1
#define CV_CONS 2


void inizializza_prod_cons(PriorityProdCons* p){

	/* TBD: Inizializzare le variabili della struttura (testa, coda, ...) */
	for(int i=0;i<DIM;i++){
		p->buffer[i]=0;
	}
	p->testa=0;
	p->coda=0;
	p->count=0;

	/* TBD: Inizializzare il sotto-oggetto "Monitor", chiamando init_monitor(...).
	        Scegliere accuratamente il numero di variabili condition */
	init_monitor(&(p->M),3); //3 perchè ho 3 varcond

}

void rimuovi_prod_cons(PriorityProdCons* p){

	/* TBD: Deallocare il sotto-oggetto "Monitor", chiamando remove_Monitor(...). */
	remove_monitor(&(p->M));
}


void produci_alta_prio(PriorityProdCons* p){

	int value;

	/* TBD: Effettuare l'ingresso nel monitor */
	enter_monitor(&(p->M));

	printf("Produttore 1 entrato nel monitor...\n");

	/* TBD: Sospendere qui il processo se il vettore di buffer è pieno */
	while(p->count==DIM){
		wait_condition(&(p->M), CV_ALTA_P);
	}

	//Produco il valore
	value = rand() % 12 ;

	//Modifico il buffer
	p->buffer[p->testa] = value;
	p->testa = (p->testa + 1) % DIM;
	p->count++;

	//Il buffer non è vuoto
	printf("Produttore 1 con pid %d ha prodotto %d\n",getpid(),value);	
	
	/* TBD: Effettuare la signal_condition per i consumatori in attesa */
	signal_condition(&(p->M),CV_CONS);
	
	/* TBD: Uscire dal monitor */
	leave_monitor(&(p->M));
}

void produci_bassa_prio(PriorityProdCons* p){

	int value;
	
	/* TBD: Effettuare l'ingresso nel monitor */
	enter_monitor(&(p->M));
	
	//Aumenta il numero di produttori
	printf("Produttore 2 entrato nel monitor...\n");
	
	/* TBD: Sospendere qui il processo se il vettore di buffer è pieno */
	while(p->count==DIM || queue_condition(&(p->M), CV_ALTA_P)>0){
		wait_condition(&(p->M),CV_BASSA_P);
	}

	//Produco il valore
	value = 13 + (rand() % 12) ; //genero num casuale tra 13 e 24, in pratica un intervallo di 12 numeri a partire da 13

	//Modifico il buffer
	p->buffer[p->testa] = value;
	p->testa = (p->testa + 1) % DIM;
	p->count++;

	//Il buffer non è vuoto
	printf("Produttore 2 con pid %d ha prodotto %d\n",getpid(),value);	

	/* TBD: Effettuare la signal_condition per i consumatori in attesa */
	signal_condition(&(p->M),CV_CONS);

	/* TBD: Uscire dal monitor */
	leave_monitor(&(p->M));

}

void consuma(PriorityProdCons* p){

	int value;

	/* TBD: Effettuare l'ingresso nel monitor */
	enter_monitor(&(p->M));

	/* TBD: Sospendere qui il processo se il vettore di buffer è vuoto */
	while(p->count == 0){
		wait_condition(&(p->M),CV_CONS);
	}


	value = p->buffer[p->coda];
	p->coda = (p->coda + 1) % DIM;
	p->count--;

	printf("Consumatore con pid %d ha consumato valore %d\n",getpid(),value);


	/* TBD: Effettuare la signal_condition per attivare un produttore.
	 *      Si attivi un produttore di priorità alta se presente, altrimenti,
	 *      si attivi un produttore di priorità bassa.
	 * 
	 * 		Per determinare se ci sono produttori ad alta priorità in attesa,
	 * 		si introduca una variabile "num_lettori_alta_priorita", che i produttori
	 *      incrementano subito prima di fare wait_condition(), e che decrementano
	 * 		subito dopo aver eseguito wait_condition().
	 * 
	 * 		In alternativa, utilizzare la funzione "queue_condition()".
	 */

	 if(queue_condition(&(p->M),CV_ALTA_P)>0){
		signal_condition(&(p->M),CV_ALTA_P);
	 }else{
			signal_condition(&(p->M),CV_BASSA_P);
	 }
	 
	/* TBD: Uscire dal monitor */
	leave_monitor(&(p->M));
}