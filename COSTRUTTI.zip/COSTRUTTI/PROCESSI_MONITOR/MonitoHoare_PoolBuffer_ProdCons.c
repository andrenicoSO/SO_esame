/****************************PRODCONS POOL DI BUFFER MONITOR HOARE***********************/

//-----------------------monitor_hoare.h---------------------------------
typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//id del semaforo per realizzare la coda urgent
  int urgent_sem;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition e della coda urgent
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

//contatore del numero di processi sospesi sulla coda urgent
  int *urgent_count;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 



//----------------------------monitor_hoare.c--------------------------------
// Implementazione di un Monitor signal-and-wait, con coda urgent (soluzione di Hoare)

#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>

#include "monitor_hoare.h"


//Funzioni di utilita' private alla libreria Monitor

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo



void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza il semaforo per la coda urgent
    M->urgent_sem=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->urgent_sem,0,SETVAL,0);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition, più un contatore per la coda urgent
    M->id_shared=shmget(IPC_PRIVATE,(num_var+1)*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;

    M->urgent_count = M->cond_counts + M->num_var_cond;


    //inizializza i contatori per le var.condition e per la coda urgent
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;

    *(M->urgent_count)=0;

#ifdef DEBUG_
    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);
#endif

} 

void enter_monitor(Monitor * M){

#ifdef DEBUG_
    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );
#endif

    Wait_Sem(M->mutex,0);

#ifdef DEBUG_
    printf("<%d> Entrato nel monitor \n",getpid() );
#endif

}

void leave_monitor(Monitor* M){

#ifdef DEBUG_
    printf("<%d> Uscito dal monitor  \n", getpid());
#endif

    if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
        Signal_Sem(M->urgent_sem,0); 
    } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
        Signal_Sem(M->mutex,0);
    }
}

void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->urgent_sem,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

#ifdef DEBUG_
    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n");
#endif

}

void wait_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);
#endif

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;

      if( *(M->urgent_count) > 0 ) {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sulla coda urgent \n", getpid());
#endif
          Signal_Sem(M->urgent_sem,0); 
      } else {
#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif
          Signal_Sem(M->mutex,0);
      }

      Wait_Sem(M->id_conds,id_var);

      M->cond_counts[id_var]=M->cond_counts[id_var]-1;
}

void signal_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
#endif     

    (*(M->urgent_count))++;

    if(M->cond_counts[id_var]>0) {

            Signal_Sem(M->id_conds,id_var);

#ifdef DEBUG_
            printf("<%d> -Monitor- invocata la signal sulla condition numero %d\n", getpid(), id_var);
#endif

#ifdef DEBUG_
            printf("<%d> -Monitor- processo in attesa sulla coda urgent \n", getpid());
#endif

            Wait_Sem(M->urgent_sem,0);

#ifdef DEBUG_
            printf("<%d> -Monitor- processo uscito dalla coda urgent \n", getpid());
#endif

    }

    (*(M->urgent_count))--;
}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}

void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}




//-------------------------------header.h----------------------------------------
#ifndef _HEADER_H_
#define _HEADER_H_

#include "monitor_hoare.h"

//definiamo produttori e consumatori
#define NUM_PRODUTTORI 6 //6 lo dice la traccia
#define NUM_CONSUMATORI 2 //lo dice la traccia

//dimensione del buffer
#define DIMENSIONE 5 //5 perchè lo dice la traccia

/*macro per la gestione delle variabili condition e del vettore di stato */
#define LIBERO 0
#define OCCUPATO 1
#define INUSO 2

//produttore e consumatore
#define VARCONDP 0
#define VARCONDC 1

//per la mutua esclusione 
#define MUTEX_P 3
#define MUTEX_C 4

typedef struct {
    int vettore[DIMENSIONE];
	int stato[DIMENSIONE];
    int num_liberi;  //si inizializza a DIMENSIONE

    /*variabili per la sincronizzazione */
	int num_occupati;
	int produttori_attesa; //count
	Monitor M;
    
} MonitorCoda;

// il valore di ritorno di produzione() indica se il monitor è sovraccarico
int produzione(MonitorCoda *m, int valore);

// il valore di ritorno di consumazione() è il valore prelevato dalla coda
int consumazione(MonitorCoda *m);

void produttore(MonitorCoda *m);
void consumatore(MonitorCoda *m);

void inizializza(MonitorCoda *m);
void rimuovi(MonitorCoda * p);

#endif



//----------------------------------procedure.c---------------------------------------
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>

#include "header.h"

void inizializza(MonitorCoda *p) {

    /* TBD: Aggiungere codice per l'inizializzazione del monitor e delle relative
     * variabili per la sincronizzazione
     */
    init_monitor(&(p->M),2); //2 è il numero di VARCOND

//queste inizializzazioni le posso fare anche nel main
    p->num_liberi = DIMENSIONE;
    p->num_occupati = 0;
    p->produttori_attesa = 0;

    for(int i = 0; i < DIMENSIONE; i++){
        p->vettore[i] = 0;
        p->stato[i] = LIBERO;
    }

}

void rimuovi(MonitorCoda * p) {
    /* TBD: Aggiungere codice per la rimozione del monitor */
    remove_monitor(&(p->M));

}


int produzione(MonitorCoda *p, int valore) {

    /* TBD: Aggiungere codice per la produzione in accordo allo schema
     * con vettore di stato, ricordando che il valore di ritorno della funzione
     * indica se il monitor è sovraccarico o meno.
     * Nel caso in cui ci siano almeno 4 produttori in attesa, bisogna forzare
     * l'uscita del processo dal monitor e ritornare un valore pari ad 1.
     * Nel caso in cui la produzione avviene normalmente ritornare un valore pari a 0.
     */

    //inizio produzione
    int ritorno=0; //fornito dalla traccia perchè devo ritornare un valore

    //entro nel monitor
    enter_monitor(&(p->M));

    //produzione
    if(p->num_liberi==0){
        p->produttori_attesa++; //siccome lavoriamo in mutua esclusione, poniamo in attesa i produttori
        wait_condition(&(p->M),VARCONDP);

        if(p->vettore[DIMENSIONE]==DIMENSIONE && p->produttori_attesa >=4){
              p->produttori_attesa--;

        leave_monitor(&(p->M));
        ritorno=1;
    }
    }

    int i=0;
    //cerco ls prima cella con stato libero 
    while (i<DIMENSIONE && p->stato[i] != LIBERO){
        i++;
    }

    //imposto lo stato della cella in uso e decremento il numero di celle libere
    p->stato[i]=INUSO;
    p->num_liberi--;

    //ESCO DAL MONITOR
    leave_monitor(&(p->M));

    sleep(1);

    //inserisco il valore nel vettore
    p->vettore[i]=valore;

    //entro nel monitor
    enter_monitor(&(p->M));

    //imposto lo stato della cella come occupato e incremento il numero di occupati
    p->stato[i]=OCCUPATO;
    p->num_occupati++;

    //riattivo i consumatori
    signal_condition(&(p->M),VARCONDC);

    //esco dal monitor
    leave_monitor(&(p->M));

    return ritorno;
}


/* NOTA: il valore di ritorno di consumazione() è il valore prelevato dalla coda */
int consumazione(MonitorCoda *p) {

    /* TBD: Aggiungere codice per la consumazione in accordo allo schema
     * con vettore di stato, ricordando che il valore di ritorno della funzione
     * indica il valore prelevato dal buffer condiviso.
     */
    int valore;

    //entro nel monitor
    enter_monitor(&(p->M));

    //controllo che il buffer sia vuoto, in questo caso non consumo
    if(p->num_occupati==0){
        wait_condition(&(p->M),VARCONDC);
    }

    int i=0;
    //scorro il buffer finchè non trovo una cella con stato OCCUPATO
    while(i<DIMENSIONE && p->stato[i]!=OCCUPATO) {
        i++;
    }
    
    //imposto lo stato della cella come INUSO e decremento il numero di occupati
	p->stato[i]=INUSO;
	p->num_occupati--;

    //esco dal monitor
	leave_monitor(&(p->M));

    sleep(2);

    //imposto il valore dell'i-esima cella
	valore=p->vettore[i];

    //rientro nel monitor
	enter_monitor(&(p->M));

    //imposto lo stato della cella come libero e incremento il numero di liberi
	p->stato[i]=LIBERO;
	p->num_liberi++;

    //segnalo ai produttori la fine della consumazione
	signal_condition(&(p->M),VARCONDP);

    //esco dal monitor
	leave_monitor(&(p->M));

    return valore;
}

void produttore(MonitorCoda *m) {
    
    int valore;
    int ret;
    int i;
    
    for(i=0; i<5; i++) {
		//5 PERCHè DEVONO ESSERE EFFETTUATE 5 PRODUZIONI SECONDO LA TRACCIA
        
        while(1) {
            
            srand(time(NULL)*getpid()); //inizializzo il gen di numeri casuali
            valore = rand() % 10;
            
            ret = produzione(m, valore); //richiamo la funzione di produzione passando il monitor e il valore prodotto sopra
            if(ret==0) { break; }
        
            printf("MONITOR SOVRACCARICO, ATTENDO 3 secondi...\n");    
            sleep(3); //3 LO DICE LA TRACCIA 
        }
        
        printf("VALORE PRODOTTO: %d\n", valore);
        
        sleep(1); //1 LO DICE LA TRACCIA
    }
    exit(0);
}

void consumatore(MonitorCoda *m) {
    
    int i;
    int valore;
    
    for(i=0; i<15; i++) {
        //15 LO DICE LA TRACCIA
        valore = consumazione(m); //richiamo la funz consumazione passando il monitor
        printf("VALORE CONSUMATO: %d\n", valore);
        
        sleep(2); //2 LO DICE LA TRACCIA
    }
    exit(0);
}



//-------------------------------main.c--------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <time.h>

#include "header.h"

int main() {

    //creazione e controllo shm
    key_t chiaveshm=IPC_PRIVATE; //se ho + eseguibili ftok(".", 'a');
    int shm_id = shmget(chiaveshm, sizeof(MonitorCoda), IPC_CREAT|0664) ;/* TBD: Ottenere un descrittore della shared memory */
    if (shm_id < 0){
        perror("Errore creazione shared memory");
        exit(1);
    }
    
    //attach
    MonitorCoda *p = (MonitorCoda*) shmat(shm_id,NULL,0);
    if (p == (void *)-1) //(void*)-1 perchè il puntatore non può puntare a 0 ma deve puntare a -1 che è l'errore
    {
        perror("Errore attach shared memory");
        exit(1);
    }

    /* Inizializzo monitor e variabili per la sincronizzazione tramite la procedura inizializza(...) */
    inizializza(p);

    //posso inizializzare anche in procedure.c (funz. inizializza)
    p->num_liberi=DIMENSIONE;
    p->num_occupati=0;
    p->produttori_attesa=0;
    
    for(int i=0;i<DIMENSIONE;i++){
        p->stato[i] = LIBERO;
    }

    /* TBD: Aggiungere codice per la creazione dei processi produttori e consumatori */
	pid_t pid;
    for(int i=0;i<NUM_PRODUTTORI;i++){
        pid=fork();
        if(pid==0){
            produttore(p);
            exit(0);
        } else if(pid<0){
            perror("errore nella fork");
        }
    }

    for(int i=0;i<NUM_CONSUMATORI;i++){
        pid=fork();
        if(pid==0){
            consumatore(p);
            exit(0);
        } else if(pid<0){
            perror("errore nella fork");
        }
    }


    /* TBD: Aggiungere codice per l'attesa della terminazione dei processi produttori e consumatori */
    //possiamo anche fare due for separati <num_prod e <num_cons 
    for(int i=0;i<NUM_PRODUTTORI+NUM_CONSUMATORI; i++){
        wait(NULL);
    }

    /* TBD: Aggiungere codice per la rimozione del monitor tramite la procedura rimuovi(...) */
    rimuovi(p);

    //rimozione shm
    shmctl(shm_id,IPC_RMID,0);
    
    return 0;
}