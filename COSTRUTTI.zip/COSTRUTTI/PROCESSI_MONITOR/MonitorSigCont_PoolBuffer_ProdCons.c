
/********************Monitor_Sig_Cont_PRODCONS_POOL_BUFFER********************* */

/*----------------PROCEDURE.H--------------------*/
#ifndef HEADER_H
#define HEADER_H

#include "monitor_signal_continue.h"

#define DIM 5 //dimensione buffer, lo dà la traccia

//stati del buffer
#define LIBERO 0
#define OCCUPATO 1
#define IN_USO 2

struct ProdCons {
	int buffer[DIM];
	int stato[DIM];

	int numero_occupati;
	int numero_liberi;
	Monitor m;
};

//variabili condition
#define VARCOND_PRODUTTORI 0
#define VARCOND_CONSUMATORI 1

void Produci(struct ProdCons * pc, int valore);
int Consuma(struct ProdCons * pc);

#endif


/*--------------PROCEDURE.C-----------------*/
#include "procedure.h"

#include <unistd.h>
#include <stdio.h>

void Produci(struct ProdCons * pc, int valore) {

	//entro nel monitor
	enter_monitor( &(pc->m) ); 
	printf("Ingresso monitor - produzione\n");

	//finchè il buffer è pieno, sospendo i produttori
	while( pc->numero_liberi == 0 ) {
		printf("Sospensione - produzione\n");
		wait_condition( &(pc->m), VARCOND_PRODUTTORI );
		printf("Riattivazione - produzione\n");
	}


	int i = 0;
	//controllo sullo stato, scorro tutto il buffer finchè non trovo una cella libera
	while( i<DIM && pc->stato[i] != LIBERO ) {
		i++;
	}

	//imposto lo stato della cella in uso e decremento il numero di liberi
	pc->stato[i] = IN_USO;
	pc->numero_liberi--;

	//esco dal monitor
	leave_monitor( &(pc->m) );

	// simulazione di operazione lenta
	sleep(2);

	//inserisco il valore nel buffer
	pc->buffer[i] = valore;
	printf("Produzione - posizione %d, valore %d\n", i, valore);

	//entro nel monitor
	enter_monitor( &(pc->m) );

	//pongo lo stato della cella come occupato e incremento il numero di occupati
	pc->stato[i] = OCCUPATO;
	pc->numero_occupati++;

	//segnalo i consumatori che la produzione è finita
	signal_condition( &(pc->m), VARCOND_CONSUMATORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - produzione\n");
}

int Consuma(struct ProdCons * pc) {

	int valore;

	//entro nel monitor 
	enter_monitor( &(pc->m) );
	printf("Ingresso monitor - consumazione\n");

	//finchè il buffer è vuoto, sospendo i consumatori
	while( pc->numero_occupati == 0 ) {
		printf("Sospensione - consumazione\n");
		wait_condition( &(pc->m), VARCOND_CONSUMATORI );
		printf("Riattivazione - consumazione\n");
	}

	int i = 0;
	//scorro il buffer finchè non trovo una cella occupata
	while( i<DIM && pc->stato[i] != OCCUPATO ) {
		i++;
	}

	//imposto la cella come in uso e decremento il numero di occupati
	pc->stato[i] = IN_USO;
	pc->numero_occupati--;

	//lascio il monitor
	leave_monitor( &(pc->m) );

	// ...operazione lenta...
	sleep(2);

	//prelevo il valore dal buffer
	valore = pc->buffer[i];
	printf("Consumazione - posizione %d, valore %d\n", i, valore);

	//entro nel monitor
	enter_monitor( &(pc->m) );

	//imposto lo stato come libero
	pc->stato[i] = LIBERO;
	pc->numero_liberi++;

	//segnalo ai produttori che la consumazione è finita
	signal_condition( &(pc->m), VARCOND_PRODUTTORI );

	//esco dal monitor
	leave_monitor( &(pc->m) );
	printf("Uscita monitor - consumazione\n");

	return valore; //quando la funzione non è void devo sempre ritornare qualcosa diverso da 0 o NULL, solitamente è la variabile int che viene dichiarata all'inizio
}


/*---------------------MONITOR SIGCONT.H-------------------------*/
#ifndef __MONITOR_H
#define __MONITOR_H

typedef struct {

//id del semaforo per realizzare il mutex del monitor
  int mutex;

//numero di variabili condition
  int num_var_cond;

//id del gruppo sem associati alle var.cond
  int id_conds;

//id della memoria condivisa per i contatori delle variabili condition
  int id_shared;

//array delle variabili condition_count
  int *cond_counts;

} Monitor;

//monitor e numero di variabili condition
void init_monitor (Monitor*, int); 
void enter_monitor(Monitor*);
void leave_monitor(Monitor*);
void remove_monitor(Monitor*);
void wait_condition(Monitor*,int);
void signal_condition(Monitor*,int);
int queue_condition(Monitor*,int); 


#endif



/*-----------------MONITOR SIGCONT.C-------------------------------*/
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <unistd.h>
#include "monitor_signal_continue.h"

static void Wait_Sem(int, int);
static void Signal_Sem (int,int);
static int Queue_Sem (int,int);   //restituisce il num di processi in attesa su un semaforo

void init_monitor (Monitor *M,int num_var){

    int i;

    //alloca e inizializza il mutex per l'accesso al monitor
    M->mutex=semget(IPC_PRIVATE,1,IPC_CREAT|0664);

    semctl(M->mutex,0,SETVAL,1);


    //alloca e inizializza i semafori con cui realizzare le var.condition
    M->id_conds=semget(IPC_PRIVATE,num_var,IPC_CREAT|0664);

    for (i=0;i<num_var;i++)
         semctl(M->id_conds,i,SETVAL,0);


    //alloca un contatore per ogni var.condition
    M->id_shared=shmget(IPC_PRIVATE,num_var*sizeof(int),IPC_CREAT|0664);


    //effettua l'attach all'array di contatori appena allocato
    M->cond_counts=(int*) (shmat(M->id_shared,0,0));

    M->num_var_cond = num_var;

    //inizializza i contatori per le var.condition
    for (i=0; i<num_var; i++)
        M->cond_counts[i]=0;


#ifdef DEBUG_
    printf("Monitor inizializzato con %d condition variables. Buona Fortuna ! \n",num_var);
#endif

} 


void enter_monitor(Monitor * M){

#ifdef DEBUG_
    printf("<%d> Tentativo di ingresso nel monitor... \t",getpid() );
#endif

    Wait_Sem(M->mutex,0);

#ifdef DEBUG_
    printf("<%d> Entrato nel monitor \n",getpid() );
#endif

}


void leave_monitor(Monitor* M){

#ifdef DEBUG_
    printf("<%d> Uscito dal monitor  \n", getpid());
    printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif 

    Signal_Sem(M->mutex,0);
}

void remove_monitor(Monitor* M){
    semctl(M->mutex,0,IPC_RMID,0);
    semctl(M->id_conds,M->num_var_cond,IPC_RMID,0);
    shmctl(M->id_shared,IPC_RMID,0);

#ifdef DEBUG_
    printf(" \n Il Monitor è stato rimosso ! Arrivederci \n", getpid());
#endif

}

void wait_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della wait (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- invocata la wait sulla condition numero %d\n", getpid(), id_var);
#endif

      M->cond_counts[id_var]=M->cond_counts[id_var]+1;

#ifdef DEBUG_
	printf("<%d> -Monitor- signal sul mutex del monitor \n", getpid());
#endif

      Signal_Sem(M->mutex,0);
     
#ifdef DEBUG_
	printf("<%d> -Monitor- wait sul semaforo %d del monitor \n", getpid(),id_var);
#endif

      Wait_Sem(M->id_conds,id_var);

#ifdef DEBUG_
	printf("<%d> -Monitor- wait sul mutex del monitor \n", getpid());
#endif
   
	Wait_Sem(M->mutex,0);
}

void signal_condition(Monitor* M,int id_var){

#ifdef DEBUG_
    if(id_var<0 || id_var>=M->num_var_cond) {
        printf("<%d> -Monitor- errore nell'invocazione della signal (idvar=%d)\n", getpid(), id_var);
    }
#endif

#ifdef DEBUG_
    printf("<%d> -Monitor- tentativo di signal; n.ro proc. in attesa sulla cond. n. %d = %d\n", getpid(), id_var,M->cond_counts[id_var]);
#endif     


   if(M->cond_counts[id_var] > 0){
	M->cond_counts[id_var]--;
	#ifdef DEBUG_
    	printf("<%d> -Monitor- signal sul semaforo %d\n", getpid(), id_var);
	#endif
	Signal_Sem(M->id_conds,id_var);
   }

}


int queue_condition(Monitor * M, int id_var){
	return M->cond_counts[id_var];
}

void Wait_Sem(int id_sem, int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;
       semop(id_sem,&sem_buf,1);   //semaforo rosso
}

// restituisce il numero di processi in attesa sul semaforo
int Queue_Sem(int id_sem, int numsem)     {
	return (semctl(id_sem,numsem,GETNCNT,NULL));
}

void Signal_Sem (int id_sem,int numsem)     {
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;
       semop(id_sem,&sem_buf,1);   //semaforo verde
}




/*-------------------------------MAIN.C---------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

#include "procedure.h"


int main() {

    //creazione e controllo shm
	key_t chiave_shm = IPC_PRIVATE; //ftok(".", 'a'); se ho + eseguibili
	int id_shm = shmget( chiave_shm, sizeof(struct ProdCons), IPC_CREAT|0664);
	if( id_shm < 0 ) {
		perror("errore shm");
		exit(1);
	}

    //attach
	struct ProdCons * pc = shmat( id_shm, NULL, 0);
	if( pc == (void*)-1 ) {
		perror("errore shmat");
		exit(1);
	}

    //inizializzazione monitor
	init_monitor( &(pc->m), 2 ); //2 perchè ho 2 varcond

	//inizializzo il buffer
	pc->numero_liberi = DIM;
	pc->numero_occupati = 0;

	//inizializzo lo stato
	int i;
	for(i = 0; i<DIM; i++) {
		pc->stato[i] = LIBERO;
	}


	pid_t pid;
	int j;
	for(j=0; j<2; j++) {
		pid = fork();
		if( pid == 0 ) {
			// figlio consumatore
			printf("Inizio consumatore\n");

			int valore = Consuma( pc );
			printf("Consumazione: %d\n", valore);

			exit(0);
		}
		else if( pid < 0 ) {
			perror("errore fork");
			exit(1);
		}
	}


	for(j=0; j<2; j++) {
		pid = fork();
		if( pid == 0 ) {
			// figlio produttore
			printf("Inizio produttore\n");
			sleep(5);

			srand(time(NULL)*getpid()); //inizializzazione generatore di num casuali ancora più randomico perchè moltiplico per il pid del processo
			int valore = rand() % 10; //attribuico un val randomico tra 0 e 10

			Produci( pc, valore);
			printf("Produzione: %d\n", valore);
			
			exit(0);
		}
	}

    //terminazione dei processi
	for(j=0; j<4; j++)
		wait(NULL);

    //rimozione monitor e shm
	remove_monitor( &(pc->m) );
	shmctl( id_shm, IPC_RMID, 0);

	return 0;
}