/**********************************LETT_SCRITT_STAVATION_ENTRAMBI******************** */

//---------------------------header.h---------------------------------------
#include <pthread.h>

#ifndef HEADER_H
#define HEADER_H

/*messaggio*/
typedef long msg; //in questo caso dobbiamo passare solo un valore messaggio e non una struct

struct LettScritt {

	/* mutex del monitor */
	pthread_mutex_t mutex;

	/* condition variables del monitor */
	pthread_cond_t ok_lett_cv;
	pthread_cond_t ok_scritt_cv;

	/* variabili di utilità per la sincronizzazione */
	int num_lettori;	// lettori attivi
	int num_scrittori;	// scrittori attivi
	int num_lettori_wait;	// lettori in attesa
	int num_scrittori_wait;	// scrittori in attesa

	/* buffer condiviso */
	msg mess;
};


void * Lettore(void *);
void * Scrittore(void *);

void Scrivi(struct LettScritt *ls, msg m);
msg Leggi(struct LettScritt *ls);

void InizioLettura(struct LettScritt *ls);
void InizioScrittura(struct LettScritt *ls);
void FineLettura(struct LettScritt *ls);
void FineScrittura(struct LettScritt *ls);

#endif


//-------------------------------procedure.c--------------------------------------
#include <stdio.h>
#include <sys/time.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "header.h"


/* Entry-point dei thread */

void * Scrittore(void* p) {

		//recupero dei parametri
		struct LettScritt * ls = (struct LettScritt *)p;

		int i;
		for(i=0; i<3; i++) {
			struct timeval t1;
			struct timezone t2;
			gettimeofday(&t1,&t2); //valore diverso ad ogni scrittura
			msg m = t1.tv_usec;
			Scrivi(ls, m);
		}

		pthread_exit(NULL);
}

void * Lettore (void * p) {

		//recupero dei parametri
		struct LettScritt * ls = (struct LettScritt *)p;

		int i;
		for(i=0; i<3; i++) {
			msg m = Leggi(ls);
		}
		//potrebbe chiedere l'id dl thread:
		//int id_th=syscall(SYS_gettid);
		//printf("LETTORE(%d): valore letto = %d\n", id_th, messaggio);
		pthread_exit(NULL);
}



/* Metodi pubblici del monitor */

msg Leggi(struct LettScritt * ls) {

		//creazione del messaggio
		msg m;

		//richiamo la funzione di inziio lettura
		InizioLettura(ls);

		/*********Lettura********/
		// NOTA: la chiamata di sistema "gettid()" è disponibile solo
		// sul sistema operativo Linux (non è portabile su altre piattaforme)
		int my_id = syscall(SYS_gettid);

	    printf("Thread #%llu, valore LETTO = [%ld] \n", my_id, ls->mess);

		//prelevo il valore dal messaggo
		m = ls->mess;

		//richiamo la funzione di fine lettura
		FineLettura(ls);

		return m;
}

void Scrivi(struct LettScritt * ls, msg m) {

		//richiamo la funz di inizio scritt
		InizioScrittura(ls);

	    /*********Scrittura********/
		// NOTA: la chiamata di sistema "gettid()" è disponibile solo
		// sul sistema operativo Linux (non è portabile su altre piattaforme)
		int my_id = syscall(SYS_gettid);

		//inserisco il messaggio nella struttura
        ls->mess = m;
	    printf("Thread #%llu Valore SCRITTO = [%ld] \n", my_id, ls->mess);

		//richiamo la fine della scrittura
		FineScrittura(ls);
}


/* Metodi privati del monitor */

void InizioLettura(struct LettScritt * ls){

	//entro nel mutex
	pthread_mutex_lock(&ls->mutex);

	//fincheè c'è almeno uno scrittore, metto in attesa i lettori
	while (ls->num_scrittori>0) {
		ls->num_lettori_wait++; //incremento i lettori in attesa
		pthread_cond_wait(&ls->ok_lett_cv, &ls->mutex);
		ls->num_lettori_wait--; //decremento i lettori in attesa
	}

	//incremento il numero di lettori
	ls->num_lettori++;

	/* NOTA: la procedura IniziaLettura() esce temporaneamente dalla
	 * sezione critica, in modo da consentire a più thread di effettuare
	 * contemporaneamente l'operazione di lettura.
	*/
	pthread_mutex_unlock(&ls->mutex);
}

void FineLettura(struct LettScritt * ls){

	//entro nel mutex
	pthread_mutex_lock(&ls->mutex);

	//decremento il numero di lettori
	ls->num_lettori--;

	//quando il numero di lettori è 0, segnalo agli scrittori che possono attivarsi
	if(ls->num_lettori == 0)
		pthread_cond_signal(&ls->ok_scritt_cv); //utilizzo la broadcast solo se ho una lista d'attesa per gli scrittori (lo specifica la traccia)

	//esco dal mutex
	pthread_mutex_unlock(&ls->mutex);
}


void InizioScrittura(struct LettScritt * ls){

	//entro nel mutex
	pthread_mutex_lock(&ls->mutex);

	//finchè ho almeno un lettore o uno scrittore, metto in attesa gli scrittori (perchè lo scrittore può scrivere solo se non'è nessun altro)
	while (ls->num_lettori > 0 || ls->num_scrittori > 0) {
		ls->num_scrittori_wait++; //incremento gli scrittori in attesa
		pthread_cond_wait(&ls->ok_scritt_cv, &ls->mutex);
		ls->num_scrittori_wait--; //decremento gli scrittori in attesa
	}

	//incremento il numero di scrittori
	ls->num_scrittori++;

	/* NOTA: La procedura InizioScrittura() esce temporaneamente dalla
	 * sezione critica, in modo da consentire ad eventuali altri thread
	 * scrittori di porsi in attesa sulla variabile-condition.
	 *
	 * Nella procedura FineScrittura(), il thread uscente risveglierà
	 * uno degli scrittori in attesa (se presente), in modo da bilanciare
	 * la starvation.
	 */

	//esco dal mutex
	pthread_mutex_unlock(&ls->mutex);
}

void FineScrittura (struct LettScritt * ls){

	//entro nel mutex
	pthread_mutex_lock(&ls->mutex);

	//decremento il numero di scrittori
	ls->num_scrittori--;

	//se ci sono scrittori in attesa, li riattivo perchè hanno priorità maggiore
	if(ls->num_scrittori_wait > 0) {

		/* se ci sono scrittori in attesa, si dà loro
		 * la priorità */
		pthread_cond_signal(&ls->ok_scritt_cv);

	} else {
		/* risveglia tutti i lettori in attesa */
		pthread_cond_broadcast(&ls->ok_lett_cv); //con broadcast perchè c'è più di un lettore
	}

	//esco dal mutex
	pthread_mutex_unlock(&ls->mutex);
}




//-------------------------------------main.c---------------------------------------
/*****PROBLEMA DEI LETTORI-SCRITTORI: soluzione mediante Threads*****/
/*Il programma sincronizza lettori e scrittori nell'accesso ad una variabile condivisa utilizzando i Pthreads. */


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>
#include "header.h"


#define NUM_THREADS 10 //traccia


int main(){

	//definisco i threads
     pthread_attr_t attr;
     pthread_t threads[NUM_THREADS];


     //creazione di una istanza di struttura monitor
     struct LettScritt * ls = malloc(sizeof(struct LettScritt));

     //inizializzazione mutex e condition
     pthread_mutex_init(&ls->mutex,NULL);
     pthread_cond_init(&ls->ok_lett_cv,NULL);
     pthread_cond_init(&ls->ok_scritt_cv,NULL);

     //inizializzazione delle variabili di stato
     ls->num_lettori = 0;
     ls->num_scrittori = 0;
     ls->num_lettori_wait = 0;
     ls->num_scrittori_wait = 0;

     //impostazione dei thread come joinable
     pthread_attr_init(&attr);
     pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);	

     //generazione di scrittori e lettori
     int k;
     for (k=0;k<NUM_THREADS; k++) {
			if (k%2)  {
	     		printf("Sono il thread Lettore (%d)\n",k);
	     		pthread_create(&threads[k], &attr, Lettore, (void *) ls);
				//nella create passo: (&threads[k] nome thread definito sopra), &attr(attributo definito sopra), Lettore(starting routine nelle procedure), (void*)ls (nome nella malloc)
	   	} else {
	    	 sleep(1);
             printf("Sono il thread Scrittore (%d)\n",k);
	     	pthread_create(&threads[k], &attr, Scrittore, (void *) ls);
			//nella create passo: (&threads[k] nome thread definito sopra), &attr(attributo definito sopra), Scrittore(starting routine nelle procedure), (void*)ls (nome nella malloc)
	    }
	}

	//per la terminazione
     for (k=0; k<NUM_THREADS;k++){
       pthread_join(threads[k],NULL);
       printf ("Thread n.ro %d terminato\n ",k);
     }

     /*deallocazione risorse*/	
     pthread_attr_destroy(&attr); // devo distruggere anche l'attributo perchè lo chiamo
     pthread_mutex_destroy(&ls->mutex);
     pthread_cond_destroy(&ls->ok_lett_cv);
     pthread_cond_destroy(&ls->ok_scritt_cv);

     free(ls);

     pthread_exit(0);
}