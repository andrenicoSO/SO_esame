/**********************************CODE_MESSAGGI_LETT_SCRITT_MULTIPROCESSO************************ */
//--------------------------------header.h--------------------------------------
#ifndef _HEADER_H_
#define _HEADER_H_

#include <pthread.h>


#define TIPO 1 // tipo di messaggio, utilizzato nella msgrcv

#define LETTORI 3 //num lettori traccia

typedef struct {
    long type;
    int valore;
} Messaggio;

typedef struct {

    // TODO: completare inserendo i campi necessari a gestire il problema dei lettori-scrittori (unico scrittore)
    pthread_mutex_t mutex;
    pthread_cond_t ok_lett_cv; //per la starvation
    pthread_cond_t ok_scritt_cv; //per la starvation

    int num_lettori;
    int num_scrittori;
    int num_lettori_attesa; //per la starvation
    int num_scrittori_attesa; //in questo esempio non serve perchè è specificato che c'è un solo scrittorore, ma in generale serve
    Messaggio msg;
} MonitorLS;

#endif


//-----------------------------sensore.c(processo1)---------------------------------------
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <unistd.h>

void main() {

    printf("Avvio processo sensore...\n");
    
    int key_coda =  ftok(".",'a'); //ftok perchè 2 eseguibili diversi nel caso opposto IPC_CREATE
    int id_coda_sensore = msgget(key_coda, IPC_CREAT|0664); //o al posto di ipc_creat perchè non siamo nel main principale

    srand(time(NULL));

    for(int i=0; i<10; i++) {

        // TODO: inviare interi casuali sulla coda
        //richiamo il tipo di messaggio e gli assegno un valore (in questo caso random tra 0 e 100)
        Messaggio msg;
        msg.type = TIPO;
        msg.valore = rand () %101;

        msgsnd(id_coda_sensore,(void*)&msg,sizeof(Messaggio)-sizeof(long),0);
        //nella send metto: id_coda(dalla msgget), (void*)&msg (msg = nome var struct), sizeof(STRUCT)-sizeof(long), flag(0))

        sleep(1);
    }

}



//---------------------------------smistatore.c(processo2)------------------------------
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <pthread.h>

void * thread_lettore(void *);
void * thread_scrittore(void *);

// Variabile globale
int id_coda_sensore;

int lettura(MonitorLS * m) {

    /* 
        NOTA: C'è un unico scrittore
    */
     
    int val;

    // TODO: completare lettura
    //entro nel mutex
    pthread_mutex_lock(&m->mutex);

    //finchè ci sono scrittori, metto in attesa i lettori (i lettori si attivano se ci sono anche altri lettori, se ci sono scrittori no)
    while(m->num_scrittori >0){
        m->num_lettori_attesa++; //incremento i lettori in attesa 
        pthread_cond_wait(&m->ok_lett_cv,&m->mutex);
        m->num_lettori_attesa--; //decremento i lettori in attesa
    }
    //incremento il num di lettori
    m->num_lettori++;

    //prelevo il valore dal messaggio   
    val = m->msg.valore;

    //decremento i lettori
    m->num_lettori--;

    //riattivo gli scrittori se sono l'ultimo lettore
    if(m->num_lettori==0){ 
        pthread_cond_signal(&m->ok_scritt_cv);
    }

    //esco dal mutex
    pthread_mutex_unlock(&m->mutex);

    return val;
}

void scrittura(MonitorLS * m, int valore) {
    
    /* 
        NOTA: C'è un unico scrittore
    */

    // TODO: completare scrittura
    //entro nel mutex
    pthread_mutex_lock(&m->mutex);
    //finchè c'è almeno un lettore, pongo in attesa lo scrittore (lo scrittore scrive se non ci sono nè lettori nè altri scrittori)
    while(m->num_lettori>0){
       // m->num_scrittori_attesa++; non serve perchè c'è uno scrittore, ma in generale serve se c'è + di uno scrittore
        pthread_cond_wait(&m->ok_scritt_cv,&m->mutex);
       // m->num_scrittori_attesa--; non serve perchè c'è uno scrittore, ma in generale serve se c'è + di uno scrittore
    }

    //m->num_scrittori++; non serve perchè c'è uno scrittore, ma in generale serve se c'è + di uno scrittore
    m->msg.valore = valore;
    // m->num_scrittori--; non serve perchè c'è uno scrittore, ma in generale serve se c'è + di uno scrittore

    //non serve perchè c'è uno scrittore, ma in generale serve se c'è + di uno scrittore
    /* if(m->num_scrittori_attesa>0){
        pthread_cond_signal(&m->ok_scritt_cv);
} */ 

    //se c'è almeno un lettore in attesa, con cond_broadcast li riattivo tutti, perchè così il primo riattiva il secondo che riattiva il terzo ecc...
    if(m->num_lettori_attesa>0) {
        pthread_cond_broadcast(&m->ok_lett_cv);
}
    //esco dal mutex
    pthread_mutex_unlock(&m->mutex);
}

void main() {

	srand(time(NULL));

	int key_coda = ftok(".",'a'); //nel caso di un eseguibile utilizzo IPC_PRIVATE
    id_coda_sensore = msgget(key_coda, IPC_CREAT|0664); //possiamo mettere 0 al posto di ipc_creat perchè non è il main principale

    printf("Avvio processo smistatore...\n");

    //definizione dei thread (solitamente li dà la traccia)
    pthread_t scrittore;
    pthread_t lettori[LETTORI];

    //creazione e inizializzazione oggetto monitor
    MonitorLS * m =  malloc(sizeof(MonitorLS));

    // TODO: inizializzare variabili per la mutua esclusione
    pthread_mutex_init(&m->mutex,NULL);
    pthread_cond_init(&m->ok_lett_cv,NULL);
    pthread_cond_init(&m->ok_scritt_cv,NULL);
    m->num_lettori =0;
    m->num_scrittori =0;
    m->num_lettori_attesa = 0;
    m->num_scrittori_attesa = 0;

    // TODO: creare thread scrittore
    pthread_create(&scrittore,NULL,thread_scrittore,(void*)m);
    //ci passiamo: &scrittore(thread definito sopra), NULL(attributi del thread), thread_scrittore(starting routine nelle proceudre), (void*)m (m valore vicino alla struct malloc) 

    for(int i=0; i<3; i++) {
    	// TODO: creare thread lettori
        pthread_create(&lettori[i],NULL,thread_lettore,(void*)m);
        //ci passiamo: &lettori[i](thread definito sopra), NULL(attributi del thread), thread_lettore(starting routine nelle proceudre), (void*)m (m valore vicino alla struct malloc) 
        //nell'ultimo parametro di pth_create non passo (void*)m[i] perchè m non è un array
    }

    // TODO: attendere la terminazione dei thread
    pthread_join(scrittore,NULL); //lo scrittore è 1

    for(int i=0; i<3; i++) { 
        pthread_join(lettori[i],NULL);
    }

	// TODO: deallocare la struttura
    free(m);

}

void * thread_lettore(void * x) {

    MonitorLS * ls = (MonitorLS *)x ;// TODO: recupero parametri

    for(int i=0; i<10; i++) {
        sleep(1);

        // TODO: leggere il valore, moltiplicarlo per un intero tra 1 e 100 e stamparlo a video
        int valore_old = lettura(ls);
        int valore= valore_old * (1+ rand()%100);

        printf("Lettore: Stampo valore originale = %d e valore finale = %d\n", valore_old, valore);
    }

    pthread_exit(NULL);
}


void * thread_scrittore(void * x) {

    MonitorLS * ls = (MonitorLS*)x;// TODO: recupero parametri

    for(int i=0; i<10; i++) {

        printf("Smistatore: In attesa di messaggi...\n");

        // TODO: ricezione messaggio
        Messaggio msg;
        msgrcv(id_coda_sensore,(void*)&msg,sizeof(Messaggio)-sizeof(long),TIPO,0);
        //nella msgrcv passo: id_coda(nel main con msgget), (void*)&msg (puntatore creato sopra), sizeof(nome struct)-sizeof(long), TIPO(tipo del messaggio nella define), flag(0))

        printf("Scrittore: Ricevuto valore = %d\n", msg.valore);

        // TODO: scrivere il messaggio nel monitor
        scrittura(ls, msg.valore);
    }

    pthread_exit(NULL);
}



//---------------------------------main.c-----------------------------------------
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {

	int key_coda = ftok(".",'a');// se ho un solo eseguibile IPC_PRIVATE
    int id_coda_sensore = msgget(key_coda,IPC_CREAT|0664);// TODO
    if(id_coda_sensore < 0) {
        perror("Errore msgget");
        exit(1);
    }

    pid_t pid;
    pid = fork();
    if(pid == 0) {
        // TODO: processo figlio sensore (eseguibile distinto) //execl
        execl("./sensore","sensore",NULL);
        exit(0);
    }

    pid = fork();
    if(pid == 0) {
       // TODO: processo figlio smistatore (eseguibile distinto)
        execl("./smistatore","smistatore",NULL);
        exit(0);
    }


    // TODO: attendere completamento dei figli
    wait(NULL);

    // TODO: rimuovere la coda
    msgctl(id_coda_sensore,IPC_RMID,0);
    
    return 0;

}