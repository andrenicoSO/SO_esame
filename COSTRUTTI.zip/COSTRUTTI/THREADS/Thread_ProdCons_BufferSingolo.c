/**********************************Prod_Cons_Buffer_Singolo************************* */
//--------------------------header.h--------------------------------------------
#include <pthread.h>
#ifndef HEADER_H
#define HEADER_H

/*messaggio*/
typedef long msg; //perchè utilizziamo un messaggio non definito mediante struttura

struct ProdCons {

	/* mutex del monitor */
	pthread_mutex_t mutex;

	/* condition variables del monitor */
	pthread_cond_t ok_prod_cv;
	pthread_cond_t ok_cons_cv;

	/* variabili di utilità per la sincronizzazione */
	int ok_produzione;  //libero
	int ok_consumo;     //occupato

	/* buffer condiviso */
	msg mess;
};


void * Consumatore(void *);
void * Produttore(void *);

void Produci(struct ProdCons *, msg m);
msg Consuma(struct ProdCons *);

void InizioConsumo(struct ProdCons *);
void InizioProduzione(struct ProdCons *);
void FineConsumo(struct ProdCons *);
void FineProduzione(struct ProdCons *);

#endif




//--------------------------------procedure.c-------------------------------------
#include <stdio.h>
#include <sys/time.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "header.h"


/* Metodi pubblici del monitor */

void Produci(struct ProdCons * pc, msg m) {

		//richiamo l'inizio produzione
		InizioProduzione(pc);

	    /*********Produzione********/
		//impostare il valore 
    	pc->mess = m;

		// NOTA: la chiamata di sistema "gettid()" è disponibile solo
		// sul sistema operativo Linux (non è portabile su altre piattaforme)
        int my_id = syscall(SYS_gettid); 
	    printf("Thread #%llu Valore PRODOTTO = [%ld] \n", my_id, pc->mess);

		//richiamo la fine della produzione
		FineProduzione(pc);
}

msg Consuma(struct ProdCons * pc) {

		//definisco il messaggio
		msg m;

		//richiamo l'inizio del conusmo
		InizioConsumo(pc);

		/*********Consumo********/
		// NOTA: la chiamata di sistema "gettid()" è disponibile solo
		// sul sistema operativo Linux (non è portabile su altre piattaforme)
		int my_id = syscall(SYS_gettid);
	    printf("Thread #%llu, valore CONSUMATO = [%ld] \n", my_id, pc->mess);

		//prelevo il valore del messaggio
		m = pc->mess;

		//richiamp la funzione di fine consumo
		FineConsumo(pc);

		return m;
}



/* Metodi privati del monitor */

void InizioConsumo(struct ProdCons * pc){

	//entro nel mutex
	pthread_mutex_lock(&pc->mutex);

	//finchèm il buffer è vuoto, pongo in attesa i consumatori
	while (pc->ok_consumo==0)
		pthread_cond_wait(&pc->ok_cons_cv, &pc->mutex);

	//esco dal mutex
	pthread_mutex_unlock(&pc->mutex);

}

void FineConsumo(struct ProdCons * pc){

	//entro nel mutex
	pthread_mutex_lock(&pc->mutex);

    pc->ok_produzione = 1; //sarebbe libero, che essendo 1 vuol dire che la condizione è vera
	pc->ok_consumo = 0; //sarebbe occupato, che essendo 0 vuol dire che è falsa la condizione

	//segnalo ai produttori che la consumazione è finita, quindi li riattivo
	pthread_cond_signal(&pc->ok_prod_cv);

	//esco dal mutex
	pthread_mutex_unlock(&pc->mutex);
}


void InizioProduzione(struct ProdCons * pc){

	//entro nel mutex
	pthread_mutex_lock(&pc->mutex);

	//finchè il buffer è pieno, metto in attesa i produttori
	while (pc->ok_produzione==0)
		pthread_cond_wait(&pc->ok_prod_cv, &pc->mutex);

	//esco dal mutex
	pthread_mutex_unlock(&pc->mutex);

}

void FineProduzione (struct ProdCons * pc){

	//entro nel mutex
	pthread_mutex_lock(&pc->mutex);

	pc->ok_consumo = 1;  //sarebbe occupato, che essendo 1 vuol dire che è vera la condizione
	pc->ok_produzione = 0; //sarebbe libero, che essendo 0 vuol dire che la condizione è falsa

	//segnalo ai consumatori che la produzione è finita
	pthread_cond_signal(&pc->ok_cons_cv);

	//esco dal monitor
	pthread_mutex_unlock(&pc->mutex);
}


/* Entry-point dei thread */

void *Produttore(void* p) {

		//recupero dei parametri
		struct ProdCons * pc = (struct ProdCons *)p;

		int i;
		for(i=0; i<3; i++) {
			struct timeval t1;
			struct timezone t2;
			gettimeofday(&t1,&t2);//valore diverso ad ogni produzione
			msg m = t1.tv_usec;

			//richiamo la funzione produzione
			Produci(pc, m);
		}

		pthread_exit(NULL);
}

void * Consumatore (void * p) {

		//recuper dei parametri
		struct ProdCons * pc = (struct ProdCons *)p;

		int i;
		for(i=0; i<3; i++) {

			//richiamo la funzione consuma
			msg m = Consuma(pc);
		}

		pthread_exit(NULL);
}



//-------------------------------main.c---------------------------------------------

/*****PROBLEMA DEI PRODUTTORI-CONSUMATORI: soluzione mediante Threads*****/
/*Il programma sincronizza produttori e consumatori nell'accesso ad una variabile condivisa utilizzando i Pthreads. */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>
#include "header.h"

#define NUM_THREADS 10 //traccia

int main(){

	//definisco i thread
     pthread_attr_t attr;
     pthread_t threads[NUM_THREADS];


     //creazione di una istanza di struttura monitor
     struct ProdCons * pc = malloc(sizeof(struct ProdCons));

     //inizializzazione mutex e condition
     pthread_mutex_init(&pc->mutex,NULL);
     pthread_cond_init(&pc->ok_prod_cv,NULL);
     pthread_cond_init(&pc->ok_cons_cv,NULL);

     //inizializzazione delle variabili di stato
     pc->ok_produzione = 1; //libero
     pc->ok_consumo = 0;    //occupato


     //impostazione dei thread come joinable (si fa solo se abbiamo attr)
     pthread_attr_init(&attr);
     pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);	


     //generazione di scrittori e lettori
     int k;
     for (k=0;k<NUM_THREADS; k++) {
		/*
		  dipende dalla traccia, in questo caso ad esempio
		  threads con indice pari sono consumatori e quelli
		  con indice dispari sono produttori
		*/
		if (k%2)  {
	  	   printf("Sono il thread Consumatore, id %d \n",k);
	  	   pthread_create(&threads[k], &attr, Consumatore, (void *) pc);
		   //nella create passo: &treads[k](nome thread sopra), &attr(attributo sopra), Consumatore(starting routine nelle procedure), (void*)pc (pc = nome struct malloc)
	  	 } else {
	     sleep(1);
             printf("Sono il thread Produttore, id %d \n",k);
	     pthread_create(&threads[k], &attr, Produttore, (void *) pc);	
		//nella create passo: &treads[k](nome thread sopra), &attr(attributo sopra), Produttore(starting routine nelle procedure), (void*)pc (pc = nome struct malloc)

	    }
	}

		//distruzione dei threads
       for (k=0; k<NUM_THREADS;k++){
       pthread_join(threads[k],NULL);
       printf ("Thread n.ro %d terminato\n ",k);
     }

     /*deallocazione risorse*/	
     pthread_attr_destroy(&attr);
     pthread_mutex_destroy(&pc->mutex);
     pthread_cond_destroy(&pc->ok_prod_cv);
     pthread_cond_destroy(&pc->ok_cons_cv);
     free(pc);

     pthread_exit(0);
}