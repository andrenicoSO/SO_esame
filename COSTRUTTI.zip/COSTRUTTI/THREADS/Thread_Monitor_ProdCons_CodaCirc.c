/**********************************PROD_CONS_CODA_CIRCOLARE_COSTRUTTO_MONITOR**************/

//-------------------------Prod_Cons.h----------------------------------------
#ifndef _PRODCONS_H_
#define _PRODCONS_H_

#include <pthread.h>

#define DIM 4  //fornito dalla traccia

typedef struct {

    int buffer[DIM];

    int testa;
    int coda;
    int count;
    int uscita_timer;  //solo se lo chiede l'esercizio

    pthread_mutex_t mutex;
    pthread_cond_t cv_produttori;
    pthread_cond_t cv_consumatori;

} MonitorProdCons;

void inizializza_monitor(MonitorProdCons * m);
void distruggi_monitor(MonitorProdCons * m);
int produci(MonitorProdCons * m, int val);
int consuma(MonitorProdCons * m, int * val);

#endif



//---------------------------Prod_Cons.c-------------------------------------
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#include "prodcons.h"

/* Dichiarazione di metodo privato, che sarà
 * eseguito da un thread "timer" */
static void * thread_timer(void *);

void inizializza_monitor(MonitorProdCons * m) {

    printf("[MONITOR] Inizializzazione monitor\n");

    //inizializzazione struttura monitor
    pthread_mutex_init(&(m->mutex), NULL);
    pthread_cond_init(&m->cv_produttori, NULL);
    pthread_cond_init(&m->cv_consumatori, NULL);

    m->testa = 0;
    m->coda = 0;
    m->uscita_timer = 0;

    //creazione thread timer
    pthread_t t;
    pthread_attr_t attr;

    //inizializzazione thread perchè c'è attr
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    //crezione thread
    pthread_create(&t, &attr, thread_timer, m);
    //ci passo: &t(nome thread sopra), &attr(attributo sopra), thread_timer(starting routine sopra), m(valore monitor) (vi può anche fare con(void*)m)
}

void distruggi_monitor(MonitorProdCons * m) {

    printf("[MONITOR] Distruzione monitor\n");

    //entro nel mutex
    pthread_mutex_lock(&m->mutex);

    //setto l'uscita dal timer
    printf("[MONITOR] Terminazione thread timer\n");
    m->uscita_timer = 1;

    //esco dal mutex
    pthread_mutex_unlock(&m->mutex);

    //distruggo il mutex e le varcond
    pthread_mutex_destroy(&m->mutex);
    pthread_cond_destroy(&m->cv_produttori);
    pthread_cond_destroy(&m->cv_consumatori);
}

int produci(MonitorProdCons * m, int val) {

    //entro nel mutex
    pthread_mutex_lock(&m->mutex);

	/*
	utilizzo del timeval perchè nella traccia viene richiesto
	l'utilizzo di un timer
	*/
    struct timeval t1;
	gettimeofday(&t1,NULL);
    long start_time = t1.tv_sec*1000000 + t1.tv_usec;

    //finchè la coda è piena metto in attesa i produttori
    while(m->count == DIM) {

        printf("[MONITOR] Produttore in attesa...\n");

        pthread_cond_wait(&m->cv_produttori, &m->mutex);

        struct timeval t2;
	    gettimeofday(&t2,NULL);
        long current_time = t2.tv_sec*1000000 + t2.tv_usec;

        if(current_time - start_time >= 3000000) {

        printf("[MONITOR] Produttore ha atteso oltre 3 secondi, esce\n");

        //esco dal mutex
        pthread_mutex_unlock(&m->mutex);

        return -1; //lo chiede la traccia 
        }

    }

    //imposto il valore del buffer
    m->buffer[m->testa] = val;
    m->testa = (m->testa + 1 ) % DIM;

    //incremento il contatore
    m->count++;

    printf("[MONITOR] Produzione %d\n", val);

    //segnalo ai consumatori che la produzione è terminata
    pthread_cond_signal(&m->cv_consumatori);

    //esco dal mutex
    pthread_mutex_unlock(&m->mutex);
    
    return 0;
}

int consuma(MonitorProdCons * m, int * val) {

    //entro nel mutex
    pthread_mutex_lock(&(m->mutex));

    struct timeval t1;
	gettimeofday(&t1,NULL);
    long start_time = t1.tv_sec*1000000 + t1.tv_usec;

    //finchè il buffer è vuoto, metto in attesa i consumatori
    while(m->count == 0) {

        printf("[MONITOR] Consumatore in attesa...\n");

        pthread_cond_wait(&m->cv_consumatori, &m->mutex);

        struct timeval t2;
	    gettimeofday(&t2,NULL);
        long current_time = t2.tv_sec*1000000 + t2.tv_usec;

        if(current_time - start_time >= 3000000) {

            printf("[MONITOR] Consumatore ha atteso oltre 3 secondi, esce\n");

            //esco dal monitor
            pthread_mutex_unlock(&m->mutex);

            return -1; //-1 perchè lo chiede la traccia
        }
    }

    //prelevo il valore dal buffer
    *val = m->buffer[m->coda];
    m->coda = (m->coda + 1 ) % DIM;

    //decremento il contatore
    m->count--;

    printf("[MONITOR] Consumazione %d\n", *val);

    //segnalo ai produttori che la consumazione è finita
    pthread_cond_signal(&m->cv_produttori);

    //esco dal mutex
    pthread_mutex_unlock(&m->mutex);
    return 0;
}

//il timer è un thread richiesto dalla traccia
void * thread_timer(void * p) {

    printf("[MONITOR] Avvio thread timer\n");

    //recupero dei parametri
    MonitorProdCons * m = (MonitorProdCons *)p;

    while(1) {

        int uscita = 0;

        sleep(1); //traccia

        //entro nel mutex
        pthread_mutex_lock(&m->mutex);

        printf("[MONITOR] Thread timer\n");

        //broadcast eprchè riattivo tutti i prod e i cons
        pthread_cond_broadcast(&m->cv_produttori);
        pthread_cond_broadcast(&m->cv_consumatori);

        uscita = m->uscita_timer;

        //esco dal mutex
        pthread_mutex_unlock(&m->mutex);


        if(uscita != 0) {
            break;
        }
    }

    printf("[MONITOR] Uscita thread timer\n");

    pthread_exit(NULL);
}



//---------------------------------------main.c--------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "prodcons.h"

void * produttore(void *);
void * consumatore(void *);

int main() {

    //creazione thread
    pthread_t t_produttori[5];  //5 lo richiede la traccia
    pthread_t t_consumatore;

    printf("[MAIN] inizializza_monitor\n");

    //INIZIALIZZAZIONE STRUTTURA
    MonitorProdCons * m = (MonitorProdCons *)malloc(sizeof(MonitorProdCons));

    //richiamo la funzione inizializza
    inizializza_monitor(m);

    srand(time(NULL));

    printf("[MAIN] pthread_create\n");

    for(int i=0; i<5; i++) {
        //creo i thread produttori
        pthread_create(&t_produttori[i], NULL, produttore, m);
        //ci passo: &t_prod[i](nome sopra), NULL(non abbiamo attributi), produttore(starting routine sopra), m(dalla malloc)
    }

    //creazione thread consumatore
    pthread_create(&t_consumatore, NULL, consumatore, m);


    printf("[MAIN] pthread_join\n");

    //distruzione thread
    for(int i=0; i<5; i++) {

        pthread_join(t_produttori[i], NULL);
    }

    pthread_join(t_consumatore, NULL);


    printf("[MAIN] distruzione_monitor\n");

    //DISTRUZIONE E DEALLOCAZIONE MONITOR
    distruggi_monitor(m);
    free(m);

}


void * produttore(void * p) {

    printf("[MAIN] Avvio thread produttore\n");

    //recupero parametri
    MonitorProdCons * m = (MonitorProdCons *)p;

    for(int i=0; i<4; i++) {

        int val = rand() % 10;

        printf("[MAIN] Produttore ha generato %d\n", val);

        int ret = produci(m, val);

        while(ret < 0) {

            sleep(1);

            printf("[MAIN] Produttore ritenta inserimento di %d\n", val);

            ret = produci(m, val);
        }

    }

    pthread_exit(NULL);
}


void * consumatore(void * p) {

    printf("[MAIN] Avvio thread consumatore\n");

    //recuper dei parametri
    MonitorProdCons * m = (MonitorProdCons *)p;

    for(int i=0; i<20; i++) {

        int val;

        int ret = consuma(m, &val);

        printf("[MAIN] Consumatore ha prelevato %d\n", val);

        sleep(2);
    }

    pthread_exit(NULL);
}
