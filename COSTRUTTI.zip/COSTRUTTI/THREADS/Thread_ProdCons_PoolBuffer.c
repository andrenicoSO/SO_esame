/**********************************THREAD_POOL_BUFFER_PROD_CONS******************** */
//-----------------------header.h------------------------------------------------
#define DIM 5 //dimensione buffer (traccia)

//stati del buffer
#define LIBERO 0
#define IN_USO 1
#define OCCUPATO 2

typedef struct {
    int buffer[DIM];            //ovviamente varia in qualsiasi tipo
    int stato[DIM];             //lo stato conta quindi sempre int
    int num_occupati;           //da inizializzare a 0 nel main
    int num_liberi;             //da inizializzare a DIM nel main

    //varcond e mutex
    pthread_mutex_t mutex;                
    pthread_cond_t OK_CONS;
    pthread_cond_t OK_PROD;    
}CodaStato;



//---------------------------------procedure.c------------------------------------
//usiamo una struttura differenziata ma volendo posso mettere anche tutto in 2 funzioni
//Produzione e Consumazione

void Produzione (CodaStato * b, int val){

    //richiamo la funzione di produzione
    int i = InizioProduzione(b);

    //altro codice in particolare

    //imposto il valore nel buffer
    b->buffer[i] = val;

    //richiamo la fine della produzione
    FineProduzione(b,i);
    
}

int Consumazione(CodaStato * b){
    
    int val;

    //richiamo l'inizio della consumazione
    int i = InizioConsumazione(b);

    //altro codice in particolare

    //prelevo il valore dal buffer
    val = b->buffer[i];

    //richiamo la fine della consumazione
    FineConsumazione(b,i);
    return val;
}

int InizioProduzione(CodaStato * b){

    //entro nel mutex
    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    int index = 0;

    //quando ho costrutto monitor utilizzo sempre il while (monitor sigcont)
    //finchè il buffer è pieno, sospendo i produttori
    while (b->num_occupati == 1){
        printf("sospensione della produzione\n");
        pthread_cond_wait(&(b->OK_PROD), &(b->mutex));
        printf("ritorno della produzione\n");        
    }

    //scorro tutto il buffer finchè non trovo una cella con stato diverso da LIBERO e incremento l'indice
    while(index < DIM && b->stato[index] != LIBERO){    //while sempre uguale per ricercare l'indice
        index++;
    }

    //imposto lo stato della cella come IN_USO e decremento il numero di liberi
    b->stato[index] = IN_USO;
    b->num_liberi--;

    //esco dal mutex
    pthread_mutex_unlock(&(b->mutex));
}


int FineProduzione(CodaStato * b, int i){

    //entro nel mutex
    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    //imposto lo stato come OCCUPATO e aumento il numero di occupati
    b->stato[i] = OCCUPATO;
    b->num_occupati++;

    //segnalo ai consumatori che la produzione è finita e li riattivo
    pthread_cond_signal(&(b->OK_CONS));

    //esco dal mutex
    pthread_mutex_unlock(&(b->mutex));

}


int InizioConsumazione(CodaStato * b){

    //entro nel mutex
    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");
    
    int index = 0;

    //signal&continue sempre
    //finchè il buffer è libero, metto in attesa i consumatori
    while (b->num_occupati == 0){
        printf("sospensione della consumazione\n");
        pthread_cond_wait(&b->OK_CONS, &b->mutex);
        printf("ritorno della consumazione\n");        
    }

    //scorro il buffer finchè non trovo uan cella con stato diverso da OCCUPATO e incremento l'indice
    while(index < DIM && b->stato[index] != OCCUPATO){    //while sempre uguale per ricercare l'indice
        index++;
    }

    //pongo lo stato della cella come IN_USO e decremento il numero di occupati
    b->stato[index] = IN_USO;
    b->num_occupati--;

    //esco dal mutex
    pthread_mutex_unlock(&(b->mutex));
}


int FineConsumazione(CodaStato * b, int i){

    //entro nel mutex
    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    //imposto lo stato della cella come LIBERO e incremento il numero di liberi
    b->stato[i] = LIBERO;
    b->num_liberi++;

    //segnalo ai produttori che la consumazione è finita e li riattivo
    pthread_cond_signal(&b->OK_PROD, &b->mutex);

    //esco dal mutex
    pthread_mutex_unlock(&(b->mutex));
}



//--------------------------------------main.c----------------------------------------
int main{
#include <pthread.h>

//la struttura nel main creata sempre identica

//creo i threads
pthread_t threads[N];                //array tipo threads

pthread_attr_t attr;                 //creo attributo
pthread_attr_init (&attr);           //lo inizializzo

pthread_attr_getdetachstate(&attr, PTHREAD_CREATE_JOINABLE); //crea un thread joinable
//oppure
pthread_attr_getdetachstate(&attr, PTHREAD_CREATE_DETACHED); //crea un thread non joinabile (lo dice la traccia)


//creo una struttura nello stack su cui lavora il thread. IL THREAD NON LAVORA SU SHARED
//inizializzazione struttura 
struct Buffer * b = malloc(sizeof(struct Buffer));

//inizzializzo il mutex e la condition
pthread_mutex_init(b->mutex, NULL);
pthread_cond_init(b->cond1, NULL);

//andiamo a creare i vari threads (spesso con un for):
for(int i = 0; i < DIM; i++){
    pthread_create(&threads[i], &attr, funzione, (void*)b);
    //ci passo: &threads[i](i perchè è un array di threads, lo prenidiamo sopra), &attr(attributo definito sopra), funzione(starting routine, nelle procedure), (void*)b (dove b è il valore della struct nella malloc)
}

//OSSERVAZIONE: SE DICHIARATO JOINABILE LO FACCIO ALTRIMENTI NO
for(int i = 0; i < DIM; i++){
    pthread_join(threads[i],NULL);    
}

//deallocazione
pthread_attr_destroy(&attr);
pthread_mutex_destroy(&b->mutex);
pthread_cond_destroy(&b->cond);
free(b);

pthread_exit(0);
return 0;

}