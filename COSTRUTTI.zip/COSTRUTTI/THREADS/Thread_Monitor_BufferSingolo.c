/**********************************BUFFER_SINGOLO_COSTRUTTO_MONITOR***************** */
//----------------------------header.h-------------------------------------
#ifndef _HEADER_
#define _HEADER_

#include <pthread.h>

typedef struct {

    /* TBD: Aggiungere ulteriori variabili per la sincronizzazione */
    pthread_mutex_t mutex;
    pthread_cond_t prod;
    pthread_cond_t cons;

    /*int ok_prod;
    int ok_cons;*/ //li usiamo se non ci sono le macro
    int valore;
    int stato;
} BufferProdCons;

//PER LO STATO 
#define VUOTO 0
#define PIENO 1

void produci_valore(BufferProdCons * b, int valore);
int consuma_valore(BufferProdCons * b);
void * visualizza(void *);

//ABBIAMO DUE TIPI DI MESSAGGIO DIVERSI, PERCIO' DUE STRUCT
typedef struct {
    /* TBD: Definire la struttura, per inviare
            un valore di tipo intero
     */
    long tipo; // tipo del messaggio in questo caso ID del sensore
    int valore;
} messaggio_sensore;

typedef struct {
    /* TBD: Definire la struttura, per inviare
            un valore di tipo intero
     */
    long tipo;
    int value; //la media la fa lui
} messaggio_collettore;

//traccia
#define NUM_MESSAGGI_PER_SENSORE 5
#define NUM_SENSORI_PER_COLLETTORE 3
#define NUM_COLLETTORI 2


void sensore(int id_sensore, int id_queue_collettore);
void collettore(int id_collettore, int id_queue_collettore, int id_queue_server);
void server(int id_queue_server);


#endif



//------------------------server.c---------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>

#include "header.h"

void server(int id_queue_server) {

    /* TBD: Creare e inizializzare l'oggetto monitor */
    BufferProdCons * b = (BufferProdCons*)malloc(sizeof(BufferProdCons));


    /* TBD: Creare un thread, 
            e fargli eseguire la funzione "visualizza()",
            passandogli in ingresso l'oggetto monitor
     */

    //inizializzazione mutex e variabili condition
    pthread_mutex_init(&(b->mutex),NULL);
    pthread_cond_init(&(b->prod),NULL);
    pthread_cond_init(&(b->cons),NULL);
    b->stato=VUOTO;
    b->valore=0;

    //definisco il thread
    pthread_t tid;

    //creazione thread
    pthread_create(&tid,NULL,visualizza,(void*)b);
    //ci passo: &tid(nome trhead creato sopra), NULL(non ci sono attr), visualizza(starting routine nelle procedure), (void*)b (valore struct nella malloc)


    //produzione
    for(int i=0; i<NUM_MESSAGGI_PER_SENSORE; i++) {
        int somma_valori = 0;
        int media = 0;

        for(int j=0; j<NUM_COLLETTORI; j++) {

            int id_collettore = j+1;

            //creazione messaggio 
            messaggio_collettore m;

            /* TBD: Ricevere un messaggio da un collettore, con ricezione selettiva */
            msgrcv(id_queue_server,(void*)&m,sizeof(messaggio_collettore)-sizeof(long),id_collettore,0); //ricezione selettiva perchè riceve solo i messaggi con tipo=id_collettore
//nella msgrcv passo: id_coda(nel mian), (void*)&m (nome messagio sopra), sizeof(nome struct)-sizeof(long), id_collettore(tipo messaggio), flag(0))

            //assegno il valore
            int valore = m.value/* TBD */;
            printf("[SERVER] Ricevuto valore=%d\n", valore);
            
            //traccia
            somma_valori += valore;
        }

        //traccia
        media = somma_valori / NUM_COLLETTORI;

        /* TBD: Chiamare la funzione "produci_valore()",
                passandogli la variabile "media"
        */
        produci_valore(b,media);
    }


    /* TBD: Attendere la terminazione del thread, de-allocare il monitor */
    pthread_join(tid,NULL);
    pthread_mutex_destroy(&(b->mutex));
    pthread_cond_destroy(&(b->prod));
    pthread_cond_destroy(&(b->cons));

}

void * visualizza(void * p) {

    BufferProdCons * b = (BufferProdCons*)p; //cast da void* a BufferProdCons* LUI SE NON ME LO DÀ LO DEVO FARE IO = SPACCHETTAMENTO

    //consumazione
    for(int i=0; i<NUM_MESSAGGI_PER_SENSORE; i++) {
    
        int valore = consuma_valore(b); /* TBD: Utilizzare la funzione "consuma_valore()" */
        printf("[VISUALIZZA] Valore=%d\n", valore);
    }
    return NULL;
}


void produci_valore(BufferProdCons * b, int valore) {

    /* TBD: Completare questa funzione introducendo la sincronizzazione */
    //entro nel mutex
    pthread_mutex_lock(&(b->mutex));
    //finchè il buffer è pieno metto in attesa i produttori
    while(b->stato==PIENO){
        pthread_cond_wait(&(b->prod),&(b->mutex));
    }

    //assegno il valore e imposto lo stato PIENO
    b->valore = valore;
    b->stato = PIENO;

    //fine produzione, segnalo ai consumatori di riattivarsi
    pthread_cond_signal(&(b->cons));

    //esco dal monitor
    pthread_mutex_unlock(&(b->mutex));

}

int consuma_valore(BufferProdCons * b) {

    /* TBD: Completare questa funzione introducendo la sincronizzazione */
    //entro nel monitor
    pthread_mutex_lock(&(b->mutex));

    //finchè lo stato è vuoto, metto in attesa i consumatori
    while(b->stato==VUOTO){
        pthread_cond_wait(&(b->cons),&(b->mutex));
    }

    //prelevo il valore dal buffer e imposto lo stato VUOTO
    int valore = b->valore;

    b->stato = VUOTO;

    //fine consumazione, segnalo i produttori
    pthread_cond_signal(&(b->prod));
    
    //esco dal mutex
    pthread_mutex_unlock(&(b->mutex));

    return valore;
}




//------------------------------collettore.c---------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>

#include "header_msg.h"


void collettore(int id_collettore, int id_queue_collettore, int id_queue_server) {

    for(int i=0; i<NUM_MESSAGGI_PER_SENSORE; i++) {

        int somma_valori = 0;
        int media = 0;

        for(int j=0; j<NUM_SENSORI_PER_COLLETTORE; j++) {

            int id_sensore = j+1;

            messaggio_sensore m;

            /* TBD: Ricevere un messaggio da un sensore, con ricezione selettiva */
            msgrcv(id_queue_collettore,(void*)&m,sizeof(messaggio_sensore)-sizeof(long),id_sensore,0); //ricezione selettiva perchè riceve solo i messaggi con tipo=id_sensore
//mella rcv passo: id_coda(main), (void*)&m (m nome mess sopra), sizeof(nome struct)-sizeof(long), id_sensore(tipo mess sopra), flag(0)
            int valore = m.valore /* TBD */;

            printf("[COLLETTORE] Ricevuto valore=%d\n", valore);

            somma_valori += valore;
        }


        media = somma_valori / NUM_SENSORI_PER_COLLETTORE;

        messaggio_collettore m;

        /* TBD: Inviare "media" al processo server */
        m.tipo=id_collettore; //tipo del messaggio è l'id del collettore che lo invia al server sulla coda server
        m.value=media;

        msgsnd(id_queue_server,(void*)&m,sizeof(messaggio_collettore)-sizeof(long),0);
//mella snd passo: id_coda(main), (void*)&m (m nome mess sopra), sizeof(nome struct)-sizeof(long), flag(0)

        printf("[COLLETTORE] Inviato valore=%d\n", media);

    }
}


//-------------------------------------------------sensore.c----------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/msg.h>

#include "header_msg.h"

void sensore(int id_sensore, int id_queue_collettore) {

    srand(getpid());

    for(int i=0; i<NUM_MESSAGGI_PER_SENSORE; i++) {

        //creo il messaggio
        messaggio_sensore m;

        int valore = (rand() % 10) + 10;

        /* TBD: Inviare "valore" mediante messaggio */
        //inizializzo il valore del mess
        m.tipo=id_sensore;
        m.valore=valore;

        msgsnd(id_queue_collettore,(void*)&m,sizeof(messaggio_sensore)-sizeof(long),0);
//mella snd passo: id_coda(main), (void*)&m (m nome mess sopra), sizeof(nome struct)-sizeof(long), flag(0)

        printf("[SENSORE] Inviato valore=%d\n", valore);


        sleep(3);
    }
}

//----------------------------------------------main.c---------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/msg.h>

#include "header.h"

int main() {

    /* TBD: Creare le code di messaggi */
    int id_queue_collettore_1 = msgget(IPC_PRIVATE,IPC_CREAT|0664); /* TBD ftok se ho più eseguibili */
    int id_queue_collettore_2 = msgget(IPC_PRIVATE,IPC_CREAT|0664);/* TBD */
    int id_queue_server = msgget(IPC_PRIVATE,IPC_CREAT|0664);/* TBD */


    /* TBD: Creare il processo figlio Server, 
            passandogli lo id della coda */
            pid_t pid_server = fork();
                if(pid_server==0){
                        server(id_queue_server);
                        printf("server terminato\n");
                        exit(0);
                } else if(pid_server<0){
                        perror("errore fork");
                        exit(1);
                }


    int id_collettore = 1;
    /* TBD: Creare il primo processo figlio Collettore, 
            passandogli lo "id_collettore",
            l' id della coda per ricevere dai sensori,
            e l' id della coda per inviare al server
    */
        pid_t pid_collettore_1 = fork();
        if(pid_collettore_1==0){
                collettore(id_collettore,id_queue_collettore_1,id_queue_server);
                printf("collettore terminato\n");
                exit(0);
        } else if(pid_collettore_1<0){
                perror("errore fork");
                exit(1);
        }



    id_collettore = 2;    
    /* TBD: Creare il secondo processo figlio Collettore, 
            passandogli lo "id_collettore",
            lo id della coda per ricevere dai sensori,
            e lo id della coda per inviare al server
    */
   pid_t pid_collettore_2 = fork();
        if(pid_collettore_2==0){
                collettore(id_collettore,id_queue_collettore_2,id_queue_server);
                printf("collettore terminato\n");
                exit(0);
        } else if(pid_collettore_2<0){
                perror("errore fork");
                exit(1);
        }


    for(int i=0; i<NUM_SENSORI_PER_COLLETTORE; i++) {

        int id_sensore = i+1;
        /* TBD: Creare i processi figli Sensore, 
                passandogli lo "id_sensore",
                e lo id della coda per inviare al primo collettore
        */
        pid_t pid_sensore_1 = fork();
        if(pid_sensore_1==0){
                sensore(id_sensore,id_queue_collettore_1);
                printf("sensore terminato\n");
                exit(0);
        } else if(pid_sensore_1<0){
                perror("errore fork");
                exit(1);
        }

    }


    for(int i=0; i<NUM_SENSORI_PER_COLLETTORE; i++) {

        int id_sensore = i+1;

        /* TBD: Creare i processi figli Sensore, 
                passandogli lo "id_sensore",
                e lo id della coda per inviare al secondo collettore
        */
        pid_t pid_sensore_2 = fork();
        if(pid_sensore_2==0){
                sensore(id_sensore,id_queue_collettore_2);
                printf("sensore terminato\n");
                exit(0);
        } else if(pid_sensore_2<0){
                perror("errore fork");
                exit(1);
        }

    }



    /* TBD: Attendere la terminazione di tutti i processi figli */
    for(int i=0;i<9;i++){
            wait(NULL);
    }


    /* TBD: De-allocare le code di messaggi */
    msgctl(id_queue_collettore_1,IPC_RMID,0);
    msgctl(id_queue_collettore_2,IPC_RMID,0);
    msgctl(id_queue_server,IPC_RMID,0);

    
    return 0;
}