/****************************Starvation_Scrittori********************** */

//-----------------semafori.h-------------------------
//dovrebbe darli la traccia
#ifndef _PROCEDURE_H_
#define _PROCEDURE_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int Wait_Sem(int id_sem, int numsem);
int Signal_Sem(int id_sem, int numsem);

#endif // _PROCEDURE_H_


//-------------------------semafori.c--------------------------------
//dovrebbe darli la traccia
#include <stdio.h>
#include <errno.h>

#include "semafori.h"


int Wait_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;

       err = semop(id_sem,&sem_buf,1);   //semaforo rosso

       if(err<0) {
         perror("Errore WAIT");
       }

       return err;
}


int Signal_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;

       err = semop(id_sem,&sem_buf,1);   //semaforo verde

       if(err<0) {
         perror("Errore SIGNAL");
       }

       return err;
}


//------------------------header.h--------------------------------
//definisco due semafori: 
#define MUTEXL 0 //sem per l'accesso alla var numlettori (variabile della struct)
#define SYNCH 1 //per la mutua esclusione tra lett/scritt e soli scritt

#define NUM_VOLTE 6 //traccia

typedef long  msg; //va fatto sempre 

typedef struct {
        int numlettori;
        msg messaggio; //mess da produrre
} Buffer;


void Lettore(int,Buffer*);
void Scrittore(int,Buffer*);

//---------------------procedure.c---------------------------------
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#include "header.h"
#include "semafori.h"

void InizioLettura(int sem, Buffer* buf){

    /*
        entra nella sez critica
        incremento il num_lettori
        faccio un controllo sui lettori, se è il primo sospendo gli scrittori (wait su synch)
        riattivo gli altri lettori (signal su mutex_l)
    */

    //entro nella sez critica (lettura)
    Wait_Sem(sem, MUTEXL); 
    //incremento numlettori in mutua esclusione
    buf->numlettori = buf->numlettori + 1;
    
    if (buf->numlettori == 1) //se si tratta del primo lettore blocca gli scrittori e acquisisci il sem
        Wait_Sem(sem, SYNCH);
    
    Signal_Sem(sem, MUTEXL); //Rilascia il mutex per far entrare altri lettori
}

void FineLettura(int sem, Buffer* buf){

       /*
        entra nella sez critica
        decremento il numero di lettori
        faccio un controllo sui lettori, se è l'ultimo riattivo gli scrittori (signal su synch)
        riattivo gli altri lettori (signal su mutex_l)
        */
    
    Wait_Sem(sem, MUTEXL); //Indica ai lettori che sto terminando la lettura, decremento
    // numlettori in mutua esclusione
    buf->numlettori = buf->numlettori - 1;
    
    if (buf->numlettori == 0) //se sono l'ultimo lettore devo rilasciare la risorsa per gli scrittori
        Signal_Sem(sem, SYNCH);
    
    Signal_Sem(sem, MUTEXL); //rilascio il mutex per altri lettori
}


void InizioScrittura(int sem){
    //sospendo gli scrittori, quindi li utilizzo
	Wait_Sem(sem, SYNCH);
}


void FineScrittura (int sem){
    //riattivo gli scrittori, non li utilizzo più
	Signal_Sem(sem, SYNCH);
}


void Scrittore(int sem, Buffer* buf) {

        //richiamo la funzione di inizio scrittura
        InizioScrittura(sem);

        /*********Scrittura********/
        struct timeval t1;
        struct timezone t2; //si può omettere e gettimeoftheday(&t1, NULL);
        gettimeofday(&t1, &t2); //per avere un valore diverso ad ogni produzione
        msg val = t1.tv_usec;
        
        //assegno il valore val al messaggio
        buf->messaggio = val;
        sleep(1);
        printf("Valore scritto=<%ld> \n", buf->messaggio);

        //richiamo la fine della scrittura
        FineScrittura(sem);
}


void Lettore (int sem, Buffer* buf) {
        //richiamo l'inizio della lettura, passando il valore sem e buf (che si trovano nella firma della funzione)
        InizioLettura(sem, buf);

        /*********Lettura********/
        sleep(1); // per simulare un ritardo di lettura
        printf("Valore letto=<%ld>, numero lettori=%d \n", buf->messaggio, buf->numlettori);
        
        //richiamo la fine della lettura
        FineLettura(sem, buf);
}


//--------------------------main.c---------------------------------
/************PROBLEMA DEI LETTORI SCRITTORI**********/
/****soluzione con attesa indefinita degli scrittori****/

/*Il programma sincronizza nell'accesso ad una zona di memoria condivisa.
  Parte dei processi esegue operazioni di esclusiva lettura,i restanti
  di esclusiva scrittura.
*/


#include <stdio.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "header.h"


int main(){

        /************DICHIARAZIONE DELLE VARIABILI***************/
        int numsem, numlettori, numscrittori; //numero semafori, num lettori e scrittori
        int status, numprocessi;
      
        numlettori = 6;
        numscrittori = 6;
        int num_processi = numscrittori + numlettori;

        //richiesta del buffer
        key_t chiave = IPC_PRIVATE; //ftok(".", 'a'); se ho più eseguibili
        int id_shared=shmget(chiave, sizeof(Buffer), IPC_CREAT | 0664);
        printf("id_shared = %d\n", id_shared);

        //attach
        Buffer * buf = (Buffer*) shmat(id_shared, 0, 0);

        //inizializzo gli elementi del buffer 
        buf->numlettori = 0;
        buf->messaggio = 0;

        //richiesta di due semafori
        key_t c_sem = IPC_PRIVATE; //ftok(".", 'b'); se ho più eseguibili
        int sem=semget(c_sem, 2, IPC_CREAT | 0664);

        //inizializzazione semafori, sempre uguale
        semctl(sem, MUTEXL, SETVAL, 1);
        semctl(sem, SYNCH, SETVAL, 1);

        //generazione di scrittori e lettori
        for (int k=0; k<num_processi; k++) {

                pid_t pid=fork();
                if (pid == 0)  { 
                        //processo figlio
                        if ( (k%2) == 0) /*se il valore è pari, lo chiedeva la traccia
                                            altrimenti come al solito */ {
                                printf("sono il figlio scrittore. Il mio pid %d \n", getpid());
                                Scrittore(sem, buf);	        
                        
                        } else {	
                                printf("sono il figlio lettore. Il mio pid %d\n", getpid());
                                Lettore(sem, buf);
                        }
                        exit(0);
                }
        }


        for (int k=0; k<num_processi; k++){
                pid_t pid=wait(&status); //faccio la wait con lo stato perchè la traccia ce lo chiede
                if (pid==-1)
                        perror("errore");
                else
                        printf("Figlio n.ro %d e\' morto con status= %d\n", pid, status);
        }

        /********DEALLOCAZIONE SEMAFORI E MEMORIA CONDIVISA**********/
        shmctl(id_shared, IPC_RMID, 0);
        semctl(sem, 0, IPC_RMID);

        return 0;
}

