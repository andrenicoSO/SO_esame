/*****************************Prod_Cons_Multiexe************************** */
//---------------------header.h------------------------------
#ifndef _P_H_
#define _P_H_

//processi
#define P1 1
#define P2 2

struct msg_calc{
	long processo;
	float numero;
};

//Genera un valore float nell'intervallo [i_dx,i_sx]
float generaFloat(int i_dx,int i_sx); 

#endif // _P_H_


//------------------procedure.c---------------------
#include <time.h>
#include <stdlib.h>

float generaFloat(int i_sx,int i_dx){
	float x = (float) (rand()+i_sx)/(float)(RAND_MAX/i_dx);
	return x;
}



//----------------------p.h-----------------------------
#ifndef _P_H_
#define _P_H_

//processi
#define P1 1
#define P2 2

struct msg_calc{
	long processo;
	float numero;
};

#endif // _P_H_


//--------------------p1.c------------------------
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "header.h"


int main() {

	printf("Processo P1 avviato\n");
    
    //definisco il messaggio richiamando la struct
	struct msg_calc m_p1;
	m_p1.processo = P1;

	key_t queue  = ftok(".", 'a'); //ftok perchè ho più eseguibili (specificato dalla traccia)
	int id_queue = msgget(queue,IPC_CREAT|0644); //0 al posto di ipc_create se non sto nel main principale
	if(id_queue < 0) {
		perror("Msgget fallita");
		exit(1);
	}

	srand(time(NULL)); //per inizializzare il generatore di numeri casuali, altrimenti tutti i programmi avranno la stessa seq. di numeri
	
	int i;
	for(i = 0; i < 11;i++){
		m_p1.numero = generaFloat(0,10);
		printf("Invio messaggio: <%lu,%f>\n",m_p1.processo,m_p1.numero);	

		msgsnd(id_queue,(void *)&m_p1,sizeof(struct msg_calc)-sizeof(long),0);
        //nella msgsend ci va: id_coda(nome della chiave), (void*)&m_p1 (valore definito con pass a rif), sizeof(nomeStruct)-sizeof(long), flag (0))

		sleep(1);
	}
	
	return 0;
}



//------------------------------p2.c-----------------------------
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "header.h"


int main() {
    //stessa cosa di quello sopra, ma utilizzo p2 al posto di p1

	printf("Processo P2 avviato\n");
	struct msg_calc m_p2;
	m_p2.processo = P2;

	key_t queue  = ftok(".", 'a'); //ftok perchè ho più eseguibili (specificato dalla traccia)
	int id_queue = msgget(queue,IPC_CREAT|0644);

	if(id_queue < 0) {
		perror("Msgget fallita");
		exit(1);
	}

	srand(time(NULL));

	
	int i;
	for(i = 0; i < 11;i++){
		m_p2.numero = generaFloat(2,20);
		printf("Invio messaggio: <%lu,%f>\n",m_p2.processo,m_p2.numero);
		msgsnd(id_queue,(void *)&m_p2,sizeof(struct msg_calc)-sizeof(long),0);
		sleep(2);
	}


	return 0;
}



//----------------p3.c------------------------------------
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>

#include "header.h"


int main() {

	printf("Processo P3 avviato\n");
	struct msg_calc m_r;
	float media_cum[2]; //traccia
	//int n_intermedio[2];

	key_t queue  = ftok(",", 'a'); //ftok perchè ho più eseguibili (specificato dalla traccia)
	int id_queue = msgget(queue,IPC_CREAT|0644);
	printf("ID QUEUE: %d\n",id_queue);
	if(id_queue < 0) {
		perror("Msgget fallita");
		exit(1);
	}

	
	int i;
	for(i = 0; i < 22;i++){
		msgrcv(id_queue,(void *)&m_r,sizeof(struct msg_calc)-sizeof(long),0,0);
    	//nella msgrcv ci va: id_coda(nome chiave), (void*)&m_r (valore in definizione del mess), sizeof(nomeStruct)-sizeof(long), tipo_messaggio(0 perchè non è def), flag (0))
		printf("Ricevuto messaggio dal processo <%lu> ,con valore <%f>\n",m_r.processo,m_r.numero);
		if(m_r.processo == P1){
	
			media_cum[P1-1]+=m_r.numero / 11;
		}else if(m_r.processo == P2){
			
			media_cum[P2-1]+=m_r.numero / 11;
		}else{
			printf("Processo non riconosciuto\n");
		}
	}

    //stampo la media
	for(i =0; i < 2;i++){
		printf("<Media %d = %f>\n",i+1,media_cum[i]);
	}
	return 0;
}




//-----------------------------main.c----------------------
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include <stdio.h>
#include <stdlib.h>

#include "header.h"


int main(int argc, char** argv) {

	pid_t pid;
	int i;

    key_t queue  = ftok(".", 'a'); //ftok perchè ho più eseguibili (specificato dalla traccia)
    int id_queue = msgget(queue, IPC_CREAT|0644);
	if(id_queue < 0) {
		perror("Msgget fallita");
		exit(1);
	}


	pid = fork();
	if(pid==0) {
		execl("./p1", "./p1", (char*)0); //execl perchè ho + eseguibili (specificato dalla traccia), può andare NULL al posto di (char*)0 e il secondo "./p1" può essere sostituito da "p1"
		perror("Exec fallita");
		exit(1);

	} else if(pid<0) {

		perror("Fork fallita");
		exit(1);
	}



	pid = fork();
	if(pid==0) {

		execl("./p2", "./p2", (char*) 0); //execl perchè ho + eseguibili (specificato dalla traccia), può andare NULL al posto di (char*)0 e il secondo "./p2" può essere sostituito da "p2"

		perror("Exec fallita");
		exit(1);

	} else if(pid<0) {

		perror("Fork fallita");
		exit(1);
	}



	pid = fork();
	if(pid==0) {

		execl("./p3", "./p2", (char*) 0); //execl perchè ho + eseguibili (specificato dalla traccia), può andare NULL al posto di (char*)0 e il secondo "./p1" può essere sostituito da "p1"

		perror("Exec fallita");
		exit(1);

	} else if(pid<0) {

		perror("Fork fallita");
		exit(1);
	}

	for(i=0; i<3; i++) {
		wait(NULL);
	}

    //rimozione coda
    msgctl(id_queue, IPC_RMID, 0);
	return 0;
}