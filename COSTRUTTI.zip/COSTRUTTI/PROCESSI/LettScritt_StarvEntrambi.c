//**********************************Starvation_Entrambi************************ */

//---------------semafori.h-----------------------------------
//dovrebbe darlo la traccia
#ifndef _SEMAFORI_H_
#define _SEMAFORI_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int Wait_Sem(int id_sem, int numsem);
int Signal_Sem(int id_sem, int numsem);

#endif // _SEMAFORI_H_



//---------------------semafori.c---------------------
//dovrebbe darlo la traccia
#include <stdio.h>
#include <errno.h>

#include "semafori.h"


int Wait_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;

       err = semop(id_sem,&sem_buf,1);   //semaforo rosso

       if(err<0) {
         perror("Errore WAIT");
       }

       return err;
}


int Signal_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;

       err = semop(id_sem,&sem_buf,1);   //semaforo verde

       if(err<0) {
         perror("Errore SIGNAL");
       }

       return err;
}



//--------------------------header.h---------------------------
#ifndef _HEADER_H_
#define _HEADER_H_

#define NUM_VOLTE 3 //traccia

//4 semafori
#define SYNCH 0 //per mutua esclusione tra lettori e scrittori
#define MUTEXS 1 //per gestire l'accesso a num_scrittori
#define MUTEXL 2 //per gestire l'accesso a num_lettori
#define MUTEX  3 //per gestire l'accesso alla risorsa in mutua escl x gli scrittori

typedef long msg;

typedef struct {
 	  	int numlettori;
 	  	int numscrittori;
 	  	msg messaggio;
} Buffer;

void InizioLettura (int, Buffer*);
void FineLettura(int, Buffer*);
void InizioScrittura(int, Buffer*);
void FineScrittura(int, Buffer*);
void Lettore(int, Buffer*);
void Scrittore(int, Buffer*);

#endif //_HEADER_H_


//--------------------------procedure.c-----------------------
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include "header.h"
#include "semafori.h"

//Procedure di inizio e fine lettura

void InizioLettura(int sem, Buffer* buf){

    /*
        entra nella sez critica
        incremento il num_lettori
        faccio un controllo sui lettori, se è il primo sospendo gli scrittori (wait su synch)
        riattivo gli altri lettori (signal su mutex_l)
    */
	
        Wait_Sem(sem, MUTEXL); //entro nella sezione critica 
                               
        buf->numlettori = buf->numlettori + 1; // incremento numlettori in mutua esclusione

        if (buf->numlettori == 1) //se si tratta del primo lettore blocca gli scrittori
            Wait_Sem(sem, SYNCH);

        Signal_Sem(sem, MUTEXL); //Rilascia il mutex per far entrare altri lettori
}

void FineLettura(int sem, Buffer* buf){

    /*
        entra nella sez critica
        decremento il numero di lettori
        faccio un controllo sui lettori, se è l'ultimo riattivo gli scrittori (signal su synch)
        riattivo gli altri lettori (signal su mutex_l)
    */

        Wait_Sem(sem, MUTEXL); //Indica ai lettori che sto terminando la lettura 
                                
        buf->numlettori = buf->numlettori - 1; //decremento numlettori in mutua esclusione

        if (buf->numlettori == 0) //se sono l'ultimo lettore devo rilasciare la risorsa per gli scrittori
     		Signal_Sem(sem, SYNCH);

        Signal_Sem(sem, MUTEXL); //rilascio il mutex per altri lettori che vogliono iniziare la lettura
}


//Procedure di inizio e fine scrittura
void InizioScrittura(int sem, Buffer* buf){
	
    /*
        entra nella sez critica (WAIT su mutex_s)
        incremento il numero di scrittori
        faccio un controllo sugli scrittori, se è il primo blocco i lettori (wait su synch)
        rlascio sezione critica (signal su mutex_s)
        blocco gli scrittori (wait su mutex)
    */

        Wait_Sem(sem,MUTEXS); //Indica agli scrittori che sto iniziando a scrivere, incremento
                                // numscrittori in mutua esclusione
        buf->numscrittori = buf->numscrittori + 1;
        
	    if (buf->numscrittori == 1) // se si tratta del primo scrittore blocca i lettori
            Wait_Sem(sem, SYNCH);

        Signal_Sem(sem,MUTEXS); //Rilascia il mutex per far entrare altri scrittori per potersi mettere in attesa
        Wait_Sem(sem,MUTEX); //Blocco eventuali scrittori per la scrittura vera e propria
}

void FineScrittura(int sem, Buffer* buf){

    /*
        riattivo gli scrittori (signal su MUTEX)
        entra nella sez critica (WAIT su mutex_s)
        decremento il numero di scrittori
        faccio un controllo sugli scrittori, se è l'ultimo sblocco i lettori (signal su synch)
        rlascio sezione critica (signal su mutex_s)
    */

        Signal_Sem(sem,MUTEX); //Rilascio il mutex per gli scrittori che devono scrivere
        Wait_Sem(sem,MUTEXS); //entro nella sez critica 
                               
        buf->numscrittori = buf->numscrittori - 1; //decremento numscrittori in mutua esclusione

        if (buf->numscrittori == 0) //se sono l'ultimo scrittore devo rilasciare la risorsa per i lettori
     		Signal_Sem(sem, SYNCH);

        Signal_Sem(sem,MUTEXS); //rilascio il mutex per altri scrittori che vogliono iniziare la scrittura
}



void Scrittore(int sem, Buffer *buf){

    //richiamo l'inizio della scrittura
	InizioScrittura(sem,buf); //valori passati stanno nella firma della funzione

    struct timeval t1;
	struct timezone t2; //si può omettere e gettimeoftheday(&t1, NULL):
    gettimeofday(&t1,&t2);    //valore diverso ad ogni scrittura

    //assegno il valore al messaggio
	buf->messaggio = t1.tv_usec;
    sleep(1);
	printf("Valore scritto: <%ld> \n", buf->messaggio);

    //richiamo la fine della scrittura
    FineScrittura(sem,buf);
}

void Lettore (int sem, Buffer* buf) {

    //richiamo l'inizio della lettura
	InizioLettura(sem,buf); //valori passati stanno nella firma della funzione

	/*********Lettura********/
	sleep(1); // per simulare un ritardo di lettura
    printf("Valore letto=<%ld>, numero lettori=%d \n", buf->messaggio, buf->numlettori);
	
    //richiamo la fine della lettura
    FineLettura(sem,buf);
}



//------------------------main.c-----------------------------------------
/****PROBLEMA DEI LETTORI-SCRITTORI CON ATTESA INDEFINITA DI ENTRAMBI****/
/*Il programma sincronizza processi lettori e processi scrittori nell'accesso ad
  una zona di memoria condivisa. La soluzione adottata può implicare starvation
  per entrambe le categorie di processi: lettori e scrittori assumono un
  comportamento perfettamente simmetrico
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>
#include "header.h"

int main(){

        //dichiarazioni variabili
        int id_sem, id_shared, k;
        int status;
        Buffer *ptr_sh;

        pid_t pid;
        int num_processi = 10;

        //creazione shm
        key_t chiave = IPC_PRIVATE; //ftok(".", 'a'); se ho più eseguibili
        id_shared=shmget(chiave, sizeof(Buffer), IPC_CREAT | 0664);
        printf("id_shared=%d \n", id_shared);
        ptr_sh=(Buffer*)(shmat(id_shared, 0, 0));

        //   Inzializzazione struttura dati
        ptr_sh->numlettori = 0;
        ptr_sh->numscrittori = 0;
        ptr_sh->messaggio = 0;	

        //   richiesta dei semafori
        key_t c_sem = IPC_PRIVATE; //ftok(".", 'a'); se ho più eseguibili
        id_sem=semget(c_sem, 4, IPC_CREAT | 0664);

        //inizializzazione mutex, sempre uguale
        semctl(id_sem, SYNCH, SETVAL, 1);
        semctl(id_sem, MUTEXL, SETVAL, 1);
        semctl(id_sem, MUTEXS, SETVAL, 1);
        semctl(id_sem, MUTEX, SETVAL, 1);

        //generazione di scrittori e lettori
        for (k=0; k<num_processi; k++) {
            pid=fork();
            if (pid == 0)  {
                     //processo figlio
                    if ((k%2) == 0) /*deve essere pari, altrimenti normale */ {
        
                            printf("sono il figlio scrittore. Il mio pid %d \n", getpid());
                            Scrittore(id_sem, ptr_sh);
                    }else {
        
                            printf("sono il figlio lettore. Il mio pid %d \n", getpid());
                            Lettore(id_sem, ptr_sh);
                    } 
                    exit(0);
            } 
        }


        for (k=0; k<num_processi; k++){
                pid = wait(&status);
                if (pid == -1)
                        perror("errore");
                else
                        printf ("Figlio n.ro %d e\' morto con status= %d \n ", pid, status);
        }
        
        //distruzione shm e sem
        shmctl(id_shared, IPC_RMID, 0);
        semctl(id_sem, 0, IPC_RMID);

        return 1;
}