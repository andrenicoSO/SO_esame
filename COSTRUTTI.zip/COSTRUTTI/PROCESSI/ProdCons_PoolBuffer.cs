/***************************ProdCons_PoolBuffer_con_VettoreStato**************************/

//----------------semafori.h---------------------
//dovrebbe darlo la traccia
#ifndef _PROCEDURE_H_
#define _PROCEDURE_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int Wait_Sem(int id_sem, int numsem);
int Signal_Sem(int id_sem, int numsem);

#endif // _PROCEDURE_H_


//----------------semafori.c----------------------
//dovrebbe darlo la traccia
#include <stdio.h>
#include <errno.h>

#include "semafori.h"


int Wait_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;

       err = semop(id_sem,&sem_buf,1);   //semaforo rosso

       if(err<0) {
         perror("Errore WAIT");
       }
       return err;
}


int Signal_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;

       err = semop(id_sem,&sem_buf,1);   //semaforo verde

       if(err<0) {
         perror("Errore SIGNAL");
       }
       return err;
}




//---------------------procedure.h-------------------------
//semafori per la sincronizzazione
#define SPAZIO_DISPONIBILE 0
#define MESSAGGIO_DISPONIBILE 1

//mutex per la mutua esclusione di produttore e consumatore 
#define MUTEX_P 2
#define MUTEX_C 3

//dimensione buffer, dato dalla traccia
#define DIM_BUFFER 3

//dato dalla traccia
#define NUM_PRODUTTORI 5
#define NUM_CONSUMATORI 5

//valori che può assumere lo stato del buffer
#define BUFFER_VUOTO 0
#define BUFFER_INUSO 1
#define BUFFER_PIENO 2

//sempre definiti buffer e stato
struct prodcons {
    int buffer[DIM_BUFFER];
    int stato[DIM_BUFFER];
};

void produttore(struct prodcons *, int);
void consumatore(struct prodcons *, int);



//-----------------procedure.c-------------------------
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>

#include "procedure.h"
#include "semafori.h"


void produttore(struct prodcons * p, int ds_sem) {
    
/*
    la funzione pruttore inizializza l'indice, attende che si liberi spazio ed entra nella sezione critica (wait sul mutex)
    scorre tutto il buffer finchè non trova una cella vuota e incrementa l'indice
    imposto lo stato di tutti gli indici del buffer come IN_USO
    esco dalla sezione critica
    simulo la pruduzione del valore e intanto lo produco
    imposto gli indici come PIENO
    segnalo ai consumatori che possono lavorare (con signal)*/

    int indice = 0;
    
    Wait_Sem(ds_sem, SPAZIO_DISPONIBILE); //attende spazio
    Wait_Sem(ds_sem, MUTEX_P); //entro nella sezione critica
    

    //scorro tutto il buffer finchè non trovo una casella vuota e incremento l'indice
    while(indice <= DIM_BUFFER && p->stato[indice] != BUFFER_VUOTO) {
        indice++;
    }
    p->stato[indice] = BUFFER_INUSO; //inizio l'operazione di utilizzo del buffer
    
    //qui devo rilasciare il mutex per i produttori...ERRORE se non lo faccio!!!!
    Signal_Sem(ds_sem, MUTEX_P);
    
    sleep(2); //...operazione lenta...
    
    //inserimento all'interno del primo posto nel buffer
    p->buffer[indice] = valore_prodotto;
    printf("Il valore prodotto = %d\n", p->buffer[indice]); //gli passo il valore prodotto

    //imposto l'elemento i-esimo del buffer come PIENO 
    p->stato[indice] = BUFFER_PIENO;
    
    Signal_Sem(ds_sem, MESSAGGIO_DISPONIBILE); //segnala i consumatori che possono accedere
}

void consumatore(struct prodcons * p, int ds_sem) {
    /*
    la funzione pruttore inizializza l'indice, attende che arrivi il messaggio ed entra nella sezione critica (wait sul mutex)
    scorre tutto il buffer finchè non trova una cella piena e incrementa l'indice
    imposto lo stato di tutti gli indici del buffer come IN_USO
    esco dalla sezione critica (signal sul mutex_c)
    simulo il prelievo del valore e intanto lo consumo 
    imposto gli indici come VUOTO
    segnalo ai PRODUTTORI che possono lavorare (con signal)
    */

    
    int indice = 0;
    
    Wait_Sem(ds_sem, MESSAGGIO_DISPONIBILE); //attende messaggio
    Wait_Sem(ds_sem, MUTEX_C); //entro nella sezione critica
    
    //scorro tutto il buffer finchè non trovo una casella occupata e incremento l'indice
    while(indice <= DIM_BUFFER && p->stato[indice] != BUFFER_PIENO) {
        indice++;
    }
    
    
    p->stato[indice] = BUFFER_INUSO; //inizio l'operazione di utilizzo del buffer

    //qui devo rilasciare il mutex per i consumatori...ERRORE se non lo faccio!!!!
    Signal_Sem(ds_sem, MUTEX_C);
    
    sleep(2); //...operazione lenta...
    
    printf("Il valore consumato = %d\n", p->buffer[indice]);
    
    //consumo del messaggio svuotando il buffer 
    p->stato[indice] = BUFFER_VUOTO;

    Signal_Sem(ds_sem, SPAZIO_DISPONIBILE); //segnala i prod
}

/*  
    Con questa soluzione MUTEX_C e MUTEX_P sono utilizzati solo 
    per l'acquisizone della cella libera tramite vettore di stato.
*/

//-------------------------main.c---------------------------
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>

#include "procedure.h"



int main() {

    //creazione chiave per shm
	key_t chiave = IPC_PRIVATE; //ftok se ho + eseguibili
	int ds_shm = shmget(chiave, sizeof(struct prodcons), IPC_CREAT|0664); // 0 al posto di ipc_creat se non è nel main principale
	if(ds_shm<0) { perror("SHM errore"); exit(1); }

    //attach
	struct prodcons * p = (struct prodcons *) shmat(ds_shm, NULL, 0); //utilizzo la struct definita nell'header

    //inizializzo il buffer
	for(int i=0; i<DIM_BUFFER; i++) {
		p->stato[i] = BUFFER_VUOTO;
	}

    //CREAZIONE CHIAVE SEM
	key_t chiavesem = IPC_PRIVATE; //ftok se ho + eseguibili
	int ds_sem = semget(chiavesem, 4, IPC_CREAT|0664); //4 perchè sono 4 semafori: MUTEX_C, MUTEX_P, SPAZIO_DISPONIBILE, MESSAGGIO_DISPONIBILE
	if(ds_sem<0) { perror("SEM errore"); exit(1); }

	
    //INIZIALIZZAZIONE DEI SEMAFORI
	semctl(ds_sem, SPAZIO_DISPONIBILE, SETVAL, DIM_BUFFER); //SPAZIO_DISP lo setto al MASSIMO(DIM_BUFFER) perchè il buffer è vuoto
	semctl(ds_sem, MESSAGGIO_DISPONIBILE, SETVAL, 0);

    //inizializzo i mutex, sempre uguale
	semctl(ds_sem, MUTEX_C, SETVAL, 1);
	semctl(ds_sem, MUTEX_P, SETVAL, 1);


    //creazione processi consumatore
	for(int i=0; i<NUM_CONSUMATORI; i++) {

		int pid = fork();
		if(pid==0) {

			//figlio consumatore
			printf("Inizio figlio consumatore\n");

			// NOTA: il generatore di numeri pseudo-casuali
			// viene inizializzato in modo diverso per ogni
			// processo (usando il valore del PID e il tempo)
			srand(getpid()*time(NULL));

			consumatore(p, ds_sem);

			exit(1);
		}
	}

    //creazione processi produttori
	for(int i=0; i<NUM_PRODUTTORI; i++) {

		int pid = fork();
		if(pid==0) {

			//figlio produttore
			printf("Inizio figlio produttore\n");

			// NOTA: il generatore di numeri pseudo-casuali
			// viene inizializzato in modo diverso per ogni
			// processo (usando il valore del PID e il tempo)
			srand(getpid()*time(NULL));

			produttore(p, ds_sem);

			exit(1);
		}
	}


    //TERMINAZIONE PROCESSI PRODUTTORI E CONSUMATORI
	for(int i=0; i<NUM_PRODUTTORI; i++) {
		wait(NULL);
		printf("Figlio produttore terminato\n");
	}

	for(int i=0; i<NUM_CONSUMATORI; i++) {
		wait(NULL);
		printf("Figlio consumatore terminato\n");
	}
        
    //rimozione shm e semafori
    shmctl(ds_shm, IPC_RMID, NULL);
    semctl(ds_sem, 0, IPC_RMID);

    return 0;

}