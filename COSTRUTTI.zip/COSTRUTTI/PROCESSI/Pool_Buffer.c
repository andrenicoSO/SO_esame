// CASO: POOL DI BUFFER (cioè con coda con vettore di stato)
#include <pthread.h>

/***********************Header.h**********************************/

#define DIM 5                   //dimensione da cambiare 

#define LIBERO 0
#define IN_USO 1
#define OCCUPATO 2


typedef struct {

    int buffer[DIM];            //ovviamente varia in qualsiasi tipo
    int stato[DIM];             //lo stato conta quindi sempre int

    int num_occupati;           //da inizializzare a 0 nel main
    int num_liberi;             //da inizializzare a DIM nel main

    pthread_cond_t OK_CONS;
    pthread_cond_t OK_PROD;    

    pthread_mutex_t mutex;                //sempre definito 

}CodaStato;



/***********************procedure.c**********************************/

//usiamo una struttura differenziata ma volendo posso mettere anche tutto in 2 funzioni
//Produzione e Consumazione



void Produzione (CodaStato * b, int val){

    int i = InizioProduzione(b);

    //altro codice in particolare

    b->buffer[i] = val;
    FineProduzione(b,i);
    
}


int Consumazione(CodaStato * b){
    
    int val;
    int i = InizioConsumazione(b);

    //altro codice in particolare

    val = b->buffer[i];
    FineConsumazione(b,i);

    return val;

}







int InizioProduzione(CodaStato * b){

    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    int index = 0;

    //signal&continue sempre
    while (b->num_occupati == 1){
        printf("sospensione della produzione\n");
        pthread_cond_wait(&(b->OK_PROD), &(b->mutex));
        printf("ritorno della produzione\n");        
    }


    while(index < DIM && b->stato[index] != LIBERO){    //while sempre uguale per ricercare l'indice
        index++;
    }

    b->stato[index] = IN_USO;
    b->num_liberi--;

    pthread_mutex_unlock(&(b->mutex));

}









int FineProduzione(CodaStato * b, int i){


    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    b->stato[i] = OCCUPATO;

    b->num_occupati++;

    pthread_cond_signal(&(b->OK_CONS));

    pthread_mutex_unlock(&(b->mutex));

}








int InizioConsumazione(CodaStato * b){

    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    int index = 0;

    //signal&continue sempre
    while (b->num_occupati == 0){
        printf("sospensione della consumazione\n");
        pthread_cond_wait((&(b->mutex)),&(b->OK_CONS));
        printf("ritorno della consumazione\n");        
    }


    while(index < DIM && b->stato[index] != OCCUPATO){    //while sempre uguale per ricercare l'indice
        index++;
    }

    b->stato[index] = IN_USO;
    b->num_occupati--;

    pthread_mutex_unlock(&(b->mutex));

}









int FineConsumazione(CodaStato * b, int i){


    pthread_mutex_lock(&(b->mutex));
    printf("accedo in mutua esclusione alla variabile protetta\n\n");

    b->stato[i] = LIBERO;

    b->num_liberi++;

    pthread_cond_signal((&(b->mutex), &(b->OK_PROD)));

    pthread_mutex_unlock(&(b->mutex));

}
