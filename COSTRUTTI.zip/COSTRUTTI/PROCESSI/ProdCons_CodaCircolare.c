//**************************ProdCons_Coda_Circolare***************************************/

//-----------------semafori.h-------------------------
//dato dalla traccia
#ifndef _PROCEDURE_H_
#define _PROCEDURE_H_

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int Wait_Sem(int id_sem, int numsem);
int Signal_Sem(int id_sem, int numsem);

#endif // _PROCEDURE_H_


//---------------------semafori.c-------------------------
//dato dalla traccia
#include <stdio.h>
#include <errno.h>

#include "semafori.h"


int Wait_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=-1;

       err = semop(id_sem,&sem_buf,1);   //semaforo rosso

       if(err<0) {
         perror("Errore WAIT");
       }

       return err;
}


int Signal_Sem (int id_sem, int numsem) {
       int err;
       struct sembuf sem_buf;

       sem_buf.sem_num=numsem;
       sem_buf.sem_flg=0;
       sem_buf.sem_op=1;

       err = semop(id_sem,&sem_buf,1);   //semaforo verde

       if(err<0) {
         perror("Errore SIGNAL");
       }

       return err;
}



//----------------------procedure.h--------------------------
//semafori per la sincronizzazione
#define SPAZIO_DISPONIBILE 0
#define MESSAGGIO_DISPONIBILE 1

//per la mutua esclusione
#define MUTEX_P 2
#define MUTEX_C 3

#define DIM_BUFFER 3 //traccia

#define NUM_PRODUTTORI 5 //traccia
#define NUM_CONSUMATORI 5 //traccia

//nella struttura va sempre inserito il buffer, testa e coda
struct prodcons {
    int buffer[DIM_BUFFER]; 
    int testa;
    int coda;
};

void produttore(struct prodcons *, int);
void consumatore(struct prodcons *, int);


//----------------------------procedure.c------------------------
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>

#include "procedure.h"
#include "semafori.h"


void produttore(struct prodcons * p, int ds_sem) {
    
    //produttore è fermo prima di wait, si sblocca dopo
    Wait_Sem(ds_sem, SPAZIO_DISPONIBILE);
    Wait_Sem(ds_sem, MUTEX_P); //inizio sezione critica
    
    sleep(2);
    
    /* genera valore tra 0 e 99
    p->buffer[p->testa] = rand() % 100;
    printf("Il valore prodotto = %d\n", p->buffer[p->testa]);
    p->testa = (p->testa+1) % DIM_BUFFER;
    */
    
    //produzione valore in testa
    p->buffer[p->testa] = valore;
    p->testa = (p->testa+1) %DIM_BUFFER;
    
    Signal_Sem(ds_sem, MUTEX_P); //rilascio la sez critica
    Signal_Sem(ds_sem, MESSAGGIO_DISPONIBILE); //riattivo i consumatori
}

void consumatore(struct prodcons * p, int ds_sem) {
    
    //consumatore è fermo prima di wai, si sblocca dopo
    Wait_Sem(ds_sem, MESSAGGIO_DISPONIBILE);    
    Wait_Sem(ds_sem, MUTEX_C); //entro nella sezione critica
    
    sleep(2);

    //il consumo può essere fatto anche fuori dalla printf:
    //int valore = p->buffer[p->coda]; 
    printf("Il valore consumato = %d\n", p->buffer[p->coda]); // e di conseguenza nella printf metto valore e non p->buffer[p->coda]
    p->coda = (p->coda + 1) % DIM_BUFFER; //incremento circolare della coda
    
    Signal_Sem(ds_sem, MUTEX_C); //rilascio sez critca
    Signal_Sem(ds_sem, SPAZIO_DISPONIBILE); //riattivo i produttori
}


//------------------------main.c---------------------------
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <time.h>

#include "procedure.h"



int main() {

    //creazione e controllo shm
	key_t chiave = IPC_PRIVATE; //ftok(".", 'a'); se ci sono più eseguibili
	int ds_shm = shmget(chiave, sizeof(struct prodcons), IPC_CREAT|0664);
	if(ds_shm<0) { perror("SHM errore"); exit(1); }

    //attach
	struct prodcons * p = (struct prodcons *) shmat(ds_shm, NULL, 0);

    //inizializzo la struttura
	p->testa = 0;
	p->coda = 0;

    //creazione e controllo sem
	key_t chiavesem = IPC_PRIVATE;
	int ds_sem = semget(chiavesem, 4, IPC_CREAT|0664);
	if(ds_sem<0) { perror("SEM errore"); exit(1); }

	
    //SEMAFORI COOPERAZIONE tra i prod e i cons
    //per settare un valore o eliminare il semaforo
    semctl(ds_sem, SPAZIO_DISPONIBILE, SETVAL, DIM_BUFFER); //imposto il val max perchè il buffer è vuoto
    semctl(ds_sem, MESSAGGIO_DISPONIBILE, SETVAL, 0);
	
    //inizializzo i mutex, sempre allo stesso modo
    semctl(ds_sem, MUTEX_C, SETVAL, 1);
    semctl(ds_sem, MUTEX_P, SETVAL, 1);


    //creazione processi, for perchè è più di 1
	for(int i=0; i<NUM_CONSUMATORI; i++) {

		int pid = fork();
		if(pid==0) {
			//figlio consumatore
			printf("Inizio figlio consumatore\n");

			// NOTA: il generatore di numeri pseudo-casuali
			// viene inizializzato in modo diverso per ogni
			// processo (usando il valore del PID e il tempo)
			srand(getpid()*time(NULL));
			consumatore(p, ds_sem);
			exit(1);
		}
	}



    //stessa cosa per i produttori
	for(int i=0; i<NUM_PRODUTTORI; i++) {

		int pid = fork();
		if(pid==0) {
			//figlio produttore
			printf("Inizio figlio produttore\n");

			// NOTA: il generatore di numeri pseudo-casuali
			// viene inizializzato in modo diverso per ogni
			// processo (usando il valore del PID e il tempo)
			srand(getpid()*time(NULL));
			produttore(p, ds_sem);
			exit(1);
		}
	}


    //distruzione procesi per produttore e consumatore
	for(int i=0; i<NUM_PRODUTTORI; i++) {
		wait(NULL);
		printf("Figlio produttore terminato\n");
	}

	for(int i=0; i<NUM_CONSUMATORI; i++) {
		wait(NULL);
		printf("Figlio consumatore terminato\n");
	}

    //distuzione sem e shm
    shmctl(ds_shm, IPC_RMID, NULL);
    semctl(ds_sem, 0, IPC_RMID);

    return 0;
}
