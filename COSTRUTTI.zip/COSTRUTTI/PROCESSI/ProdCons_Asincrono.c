//*************************Prod_Cons_Asincrono************************* */

//-----------------------header.h-----------------------------
#ifndef __HEADER
#define __HEADER

#define MESSAGGIO 1 //tipo di messaggio

typedef char msg [40]; //va sempre fatto, ovviamente 40 lo dà la traccia

typedef struct {
		long tipo; //sempre
		msg mess; //sempre
} Messaggio;

void Produttore(int queue,char* m);
void Consumatore(int queue);
void printMsgInfo(int queue);
#endif


//----------------------procedure.c-----------------------------
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include "header.h"
#include <time.h>

void Produttore(int queue, char * text) {
    //definisco il messaggio
	Messaggio m;

	// costruzione del messaggio da trasmettere
	m.tipo = MESSAGGIO;
	strcpy(m.mess,text); //copia mess da stringa text a stringa m.mess

	//invio messaggio
	msgsnd(queue, (void*)&m, sizeof(Messaggio)-sizeof(long), IPC_NOWAIT); //IPC_NOWAIT viene utilizzato quando la recieve deve essere non bloccante (specificato dalla traccia)
	//nella msgsend ci va: id_coda(firma funzione), (void*)&m (valore in definizione del mess), sizeof(nomeStruct)-sizeof(long), flag (0 o NO_WAIT))
    printf("MESSAGGIO INVIATO: <%s>\n",m.mess);
}

void Consumatore(int queue) {
    //definisco il messaggio
	Messaggio m;

	// ricezione messaggio
	msgrcv(queue, (void *) &m, sizeof(Messaggio)-sizeof(long), MESSAGGIO, 0);
	//nella msgrcv ci va: id_coda(firma funzione), (void*)&m (valore in definizione del mess), sizeof(nomeStruct)-sizeof(long), tipo_messaggio(nell'header), flag (0))
	printf("MESSAGGIO RICEVUTO: <%s>\n",m.mess);
	printMsgInfo(queue); //traccia
}

void printMsgInfo(int queue){ //traccia
	struct msqid_ds mid;
	msgctl(queue,IPC_STAT,&mid);	

    //ctime converte da tipo time.t a stringa di caratteri una data
	char *time_sender = ctime(&mid.msg_stime);
	char *time_receiver = ctime(&mid.msg_rtime);	
	char *time_ctime = ctime(&mid.msg_ctime);

	printf("Time Sender: %sTime Receiver: %sTime Ctime: %s",time_sender,time_receiver,time_ctime);
	printf("Messages Number: %lu\n",mid.msg_qnum);
}



//------------------------main.c-----------------------------------

/*********PRODUTTORE-CONSUMATORE MEDIANTE SCAMBIO DI MESSAGGI******/
/*Il programma gestisce la comunicazione tra due processi, modello asincrono 
  viene inviato un burst di messaggi e stampato lo stato della coda
*/
#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include "header.h"


int main(){

    //dichiarazione variabili
	int k,status,queue;
	pid_t pid;
	int i;
	char m[30];

	// assegnazione coda di comunicazione
	queue=msgget(IPC_PRIVATE,IPC_CREAT|0664); //fatta così perchè non ci sono le chiavi

	// generazione produttore e consumatore
	pid=fork();
	if (pid==0)  {
		printf("sono il produttore. Il mio pid %d \n",getpid());
		for(i = 0; i < 10; i++){	
			sprintf(m,"stringa %d",i);
			usleep(100);
			Produttore(queue,m);
		}
		exit(0);
	} else {
		pid=fork();		//genera il secondo figlio (consumatore)
	 	if (pid==0){
			printf("sono il figlio consumatore. Il mio pid %d \n",getpid());
			sleep(1);
        		for(i = 0; i < 10; i++){
				Consumatore(queue);
			}
			exit(0);
		}
	}

	//attesa di terminazione
	for (k=0; k<2;k++){
		pid=wait(&status);
		if (pid==-1)
			perror("errore");
		else
			printf ("Figlio n.ro %d e\' morto con status= %d\n",pid,status>>8);
	}

	//deallocazione code
	msgctl(queue,IPC_RMID,0);	
    
	return 1;
}