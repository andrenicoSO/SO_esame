//*************************PRODCONS con buffer singolo e semafori
//le implementazioni dei semafori sono fornite dalla traccia

/* FILE HEADER DELLE PROCEDURE*/

//utilizziamo due semafori: 
#define SPAZIO_DISPONIBILE 0  
#define MESSAGGIO_DISPONIBILE 1

//PROCEDURE.C

void produttore(int *p, id_semaforo):
Wait_Sem(id_semaforo, SPAZIO_DISPONIBILE);
sleep(2); //devo aspettare 2 secondi, lo dice la traccia
//di solito devo generare un valore, quindi faccio una funzione di produzione
Signal_Sem(ds_sem, MESSAGGIO_DISPONIBILE);

void consumatore(int *p, int id_semaforo):
Wait_Sem(id_semaforo, MESSAGGIO_DISPONIBILE);
sleep(2); //devo aspettare 2 secondi, lo dice la traccia
//il consumo di solito è semplicemente una printf a cui passo *p
Signal_Sem(id_semaforo, SPAZIO_DISPONIBILE);



//main.c

//operazioni relative alla chiave shm
key_t chiave = IPC_PRIVATE; //un solo eseguibile, altrimenti ftok(".", 'a');
int id_shm = shmget(chiave, sizeof(int), IPC_CREAT|0664); //se non è il main principale metto 0 al posto di IPC_CREATE
if(id_shm<0) { perror("SHM errore"); exit(1); }

//attach
tipo_dato * p;
p = (tipo_dato) shmat(id_shm, NULL, 0); 

//operazioni chiave semaforo
key_t chiavesem = IPC_PRIVATE; //un solo eseguibile, altrimenti ftok(".", 'a');
int id_sem = semget(chiavesem, 2, IPC_CREAT|0664); //se non è il main principale metto 0 al posto di IPC_CREATE
if(ds_sem<0) { perror("SEM errore"); exit(1); }
*p=0;

//inizializzazione semafori:
//per ottenere info sul sem, rimuoverlo o settarne il valore iniziale
semctl(id_sem, SPAZIO_DISPONIBILE, SETVAL, 1);
semctl(id_sem, MESSAGGIO_DISPONIBILE, SETVAL, 0);

//creazione processi e controllo
	int pid = fork();
	if(pid==0) {
		//figlio consumatore
		printf("Inizio figlio consumatore\n");
		consumatore(p, id_sem);
		exit(1);
	}


	pid = fork();
	if(pid==0) {
		//figlio produttore
		printf("Inizio figlio produttore\n");
		produttore(p, id_sem);
		exit(1);
	}


    //terminazione figli creati sopra
	wait(NULL);
	printf("primo figlio terminato\n");

	wait(NULL);
	printf("secondo figlio terminato\n");


    //rimozione shm e semaforo
    shmctl(id_shm, IPC_RMID, NULL);
   	semctl(id_sem, 0, IPC_RMID);

    return 0;