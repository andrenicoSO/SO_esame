//*******************************Prod_Cons_Sincrona*********************** */

//-----------------------------------header.h-----------------------------
//tipi di messaggio
#define REQUEST_TO_SEND 1
#define OK_TO_SEND 2
#define MESSAGGIO 3

typedef char msg [40]; //sempre, ma 40 lo dice la traccia

typedef struct {
		long tipo;
		msg mess;
	} Messaggio;

void ReceiveBloc (Messaggio *, int,int);
void SendSincr (Messaggio *, int);
void initServiceQueues(); //serve per inizializzare la coda di servizio
void removeServiceQueues(); //rimuovere coda di servizio

void Produttore(int queue, char *);
void Consumatore(int queue);


//---------------------------proceudure.c--------------------------------------
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include "header.h"

static int queue1;//statiche, non è necessaria la loro visibilità fuori dal modulo
static int queue2;


//inizializzazione code di servizio
void initServiceQueues(){

    queue1=msgget(IPC_PRIVATE,IPC_CREAT|0664); 
	queue2=msgget(IPC_PRIVATE,IPC_CREAT|0664);
}

// rimozione code di servizio
void removeServiceQueues(){
	msgctl(queue1,IPC_RMID,0);
	msgctl(queue2,IPC_RMID,0);
}

// Send Sincrona
void SendSincr (Messaggio *m , int queue){

    /*
        definiamo i messaggi
        inizializzo il tipo del messaggio (a request to send)
        invio la richiesta per comunicare (msgsnd)
        ricevo la conferma (msgrcv)
        invio il messaggio (msgsnd)
    */

    //definiamo i messaggi
	Messaggio m1,m2;

	//costruzione messaggio RTS
	m1.tipo=REQUEST_TO_SEND;
	strcpy(m1.mess,"Richiesta di invio");

	// invio messaggio RTS
	msgsnd(queue1, &m1, sizeof(Messaggio)-sizeof(long), 0);
	//nella msgsend ci va: id_coda(firma funzione), (void*)&m1 (valore in definizione del mess), sizeof(nomeStruct)-sizeof(long), flag (0))

	// ricezione OTS
	msgrcv(queue2, &m2, sizeof(Messaggio)-sizeof(long), OK_TO_SEND, 0);
	//nella msgrcv ci va: id_coda(firma funzione), (void*)&m2 (valore in definizione del mess), sizeof(nomeStruct)-sizeof(long), tipo_messaggio(nell'header), flag (0))

	// invio messaggio
	msgsnd(queue, m, sizeof(Messaggio)-sizeof(long), 0);
}

// Receive Bloccante
void ReceiveBloc (Messaggio *m, int queue, int tipomess){

    /*
        definiamo i messaggi
        ricevo la richiesta per comunicare (msgrcv), passo il tipo di messaggio
        costruisco il messaggio, ok to send
        invio la conferma (msgsnd)
        ricevo il messaggio (msgrcv)
    */

    //definiamo i messaggi
	Messaggio m1,m2;
    
    // ricezione messaggio RTS
	msgrcv(queue1,&m1,sizeof(Messaggio)-sizeof(long),REQUEST_TO_SEND,0);	
    
    // costruzione messaggio OTS
	m2.tipo=OK_TO_SEND;
	strcpy(m2.mess,"Ready to send");
	
    // invio messaggio OTS
	msgsnd(queue2,&m2,sizeof(Messaggio)-sizeof(long),0);
	
    // ricezione messaggio
	msgrcv(queue,m,sizeof(Messaggio)-sizeof(long),tipomess,0);
}

void Produttore(int queue, char * text) {
    //creazione messaggio
	Messaggio m;
	
    // costruzione del messaggio da trasmettere
	m.tipo=MESSAGGIO;
	strcpy(m.mess,text); 
	
    // invio messaggio
	SendSincr(&m,queue);
	printf("MESSAGGIO INVIATO: <%s>\n",m.mess);
}

void Consumatore(int queue) {
    //crazione messaggio
	Messaggio m;
	
    // ricezione messaggio
	ReceiveBloc(&m,queue,MESSAGGIO);
	printf("MESSAGGIO RICEVUTO: <%s>\n",m.mess);
}



//----------------------------------------main.c------------------------------

/*********PRODUTTORE-CONSUMATORE MEDIANTE SCAMBIO DI MESSAGGI******/
/*Il programma gestisce la comunicazione tra due processi, un processo
  produttore ed un processo consumatore,in un modello a memoria locale.
  Lo scambio avviene mediante protocollo sincrono realizzato a partire
  da primitive asincrone e con una comunicazione indiretta.Il program
  ma fa uso di tre mailbox:
  MB1-->SCAMBIO MSG DI SERVIZIO
  MB2-->SCAMBIO MSG DI SERVIZIO
  MB3-->SCAMBIO MSG DA TRASMETTERE
*/

#include <stdio.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <string.h>
#include "header.h"


int main(){

	int k,status,queue;
	pid_t pid;

	// assegnazione coda di comunicazione
	queue=msgget(IPC_PRIVATE,IPC_CREAT|0664);

	// inizializzazione code di servizio
	initServiceQueues();

	// generazione produttore e consumatore
	pid=fork();
	if (pid==0)  {			//processo figlio (produttore)
		printf("sono il produttore. Il mio pid %d \n",getpid());
		sleep(2);
		Produttore(queue,"www.unina.it");
		_exit(0);
	} else {
		pid=fork();		//genera il secondo figlio (consumatore)
	 	if (pid==0){
			printf("sono il figlio consumatore. Il mio pid %d \n",getpid());
			sleep(1);
        		Consumatore(queue);
			_exit(0);
		}
	}

	// attesa di terminazione
	for (k=0; k<2;k++){
		pid=wait(&status); //terminazione con status perchè lo chuede la traccia
		if (pid==-1)
			perror("errore");
		else
			printf ("Figlio n.ro %d e\' morto con status= %d\n",pid,status>>8);
	}

	// deallocazione code
	msgctl(queue,IPC_RMID,0);
	removeServiceQueues();
	
	return 1;
}
